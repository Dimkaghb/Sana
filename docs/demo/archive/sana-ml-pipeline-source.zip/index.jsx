import React from 'react';
import {Html5Audio,staticFile,AbsoluteFill,Composition,registerRoot,Sequence,useCurrentFrame,useVideoConfig} from 'remotion';
import {Opening,Capture,Windows,Kernel} from './Scenes';
import {Network,Embedding,Compare,MapScene,Decision} from './Later';
import {C,Cap,T,Shield,Rule,Box,Circle,Defs,phase,clamp,rng} from './Art';
import timing from './timing.json';
import {Transport} from './Transport';
const scenes=[Opening,Capture,Transport,Windows,Kernel,Network,Embedding,Compare,MapScene,Decision];
const chapters=['The gesture','Capturing signals','Session handoff','Sliding windows','A learned filter','The encoder','The embedding','Similarity','The population map','The decision'];
const duration=timing.reduce((n,x)=>n+x.frames,0);
function Shot({i}) {
 const frame=useCurrentFrame();const {fps}=useVideoConfig();const p=clamp(frame/(timing[i].frames-1)),dark=[4,6,9].includes(i);const paper=dark?C.deep:C.paper,ink=dark?C.cream:C.ink,muted=dark?C.sage:C.muted;
 const Scene=scenes[i];const reveal=phase(frame/fps,0,.48);
 return <AbsoluteFill style={{background:paper}}><svg viewBox="0 0 1600 900" width="100%" height="100%" xmlns="http://www.w3.org/2000/svg" style={{display:'block'}}>
 <Defs/><Box x={0} y={0} w={1600} h={900} fill={paper}/>
 <g><Shield x={102} y={57} s={.77} c={ink}/><T x={133} y={66} size={26} weight={650} fill={ink}>SANA Shield</T>
 <Cap x={1508} y={63} anchor="end" size={17} fill={muted}>MACHINE LEARNING  /  FIELD NOTES</Cap>
 <Rule x={88} y={95} x2={1512} y2={95} col={dark?'#466254':'#B9C6B3'}/></g>
 <g transform={'translate(0 '+((1-reveal)*11)+')'} opacity={.65+.35*reveal}><Scene p={p}/></g>
 <Box x={0} y={825} w={1600} h={75} fill={paper}/><Rule x={88} y={825} x2={1512} y2={825} col={dark?'#476658':'#BCC9B6'}/>
 <Cap x={89} y={862} size={15} fill={muted}>{String(i+1).padStart(2,'0')}  /  {chapters[i].toUpperCase()}</Cap>
 {rng(scenes.length).map(j=><g key={j}><Box x={1075+j*45} y={853} w={32} h={3} fill={j<i?(dark?C.mint:C.fern):dark?'#415B50':'#BECBB8'}/>{j===i&&<Box x={1075+j*45} y={852} w={Math.max(3,32*p)} h={5} fill={dark?C.coral:C.clay}/>}</g>)}
 </svg></AbsoluteFill>
}
function Film(){return <AbsoluteFill><Html5Audio src={staticFile("narration.wav")}/>{scenes.map((Scene,i)=><Sequence key={i} name={chapters[i]} from={timing.slice(0,i).reduce((s,t)=>s+t.frames,0)} durationInFrames={timing[i].frames}><Shot i={i}/></Sequence>)}</AbsoluteFill>}
function Root(){return <Composition id="Rhythm" component={Film} width={1920} height={1080} fps={24} durationInFrames={duration}/>}
registerRoot(Root);

