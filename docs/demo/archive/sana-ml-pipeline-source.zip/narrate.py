import json, math
from pathlib import Path
import numpy as np
import soundfile as sf
from kokoro_onnx import Kokoro
story = [
["A finger taps a few keys, then slides to confirm a transfer.", "How does a bank turn that small gesture into something it can compare? Let's follow one simulated session through Sana Shield."],
["The phone records the rhythm: when a key goes down, when it comes up, and how the swipe travels.", "Available motion sensors add the phone’s movement. The recording leaves out the digits you typed."],
["Now take the first two seconds. Count which signals were present, and summarize the readings inside that window.", "Move forward just one second. The windows overlap, so the middle of a gesture can appear in both views. Missing readings stay marked as missing."],
["Inside the encoder, a one-dimensional convolutional network slides a learned filter along the trace.", "It looks at neighboring moments together. The same filter can respond to a familiar movement even when it happens a little later."],
["The encoder reads three views of the same transfer. One branch summarizes the session. A second scans the motion and swipe traces.", "A third scans the overlapping windows, including flags for which signals were available. The model pools those patterns and combines the three branches."],
["Out come one hundred and twenty-eight numbers. Together they form an embedding: a compact description of how this transfer was made.", "During training, the encoder learns to bring sessions from the same labeled operator closer together and separate examples from different operators."],
["To compare two sessions, the system measures how closely their embeddings point in the same direction. This is cosine similarity.", "Here, a second session from the same simulated operator points much closer than a session from another one. A close match is a clue about behavior."],
["For an analyst, the population map turns those high-dimensional patterns into dots on a page. Each dot represents a session.", "Nearby dots suggest similar interaction patterns. Several people can move alike, so the map alone cannot tell you who held the phone."],
["Back at the transfer, the bank combines the identity evidence with checks for physical interaction and signs of coercion.", "For example, a new account without enough verified owner sessions can be asked for another check. The model supplies evidence. The decision policy chooses the next step."]
]
story.insert(2, ["When the transfer is submitted, the phone sends its observations to the bank.", "The backend checks the session format and passes it to the identity service. That's where the model inputs are prepared."])
out=Path('audio');out.mkdir(exist_ok=True)
k=Kokoro('kokoro.onnx','voices.bin'); sr=24000; fps=24
all_audio=[]; scenes=[]
for i,lines in enumerate(story):
    buf=[np.zeros(int(.50*sr))]; cues=[]
    for j,line in enumerate(lines):
        clip_id = 'transport' if i == 2 else i if i < 2 else i - 1
        path=out/f'{clip_id}-{j}.wav'
        if not path.exists():
            data,_=k.create(line,voice='af_heart',speed=1.04,lang='en-us')
            sf.write(path,data,sr)
        samples,_=sf.read(path)
        # Leave the natural onset and a short acoustic tail.
        nz=np.flatnonzero(np.abs(samples)>.0008)
        if nz.size: samples=samples[max(0,nz[0]-960):min(len(samples),nz[-1]+2400)]
        start=sum(map(len,buf))/sr;buf.extend([samples,np.zeros(round(sr*.26))]);cues.append({'start':start,'end':start+len(samples)/sr,'text':line})
    buf.append(np.zeros(round(.5*sr))); audio=np.concatenate(buf)
    frames=math.ceil(len(audio)*fps/sr); audio=np.pad(audio,(0,round(frames*sr/fps)-len(audio)))
    scenes.append({'frames':frames,'cues':cues});all_audio.append(audio)
    print(i,frames/fps,flush=True)
timeline=np.concatenate(all_audio)
# Original, quiet three-note motif at the opening and resolution.
def note(t,f,vol,length):
    t0=round(t*sr); n=min(round(length*sr),len(timeline)-t0); x=np.arange(n)/sr
    voice=np.sin(2*np.pi*f*x)+.27*np.sin(4*np.pi*f*x)
    timeline[t0:t0+n]+=vol*voice*(1-np.exp(-x/.024))*np.exp(-x/(length*.28))*np.minimum(1,(length-x)/.09)
for idx,(frame,offs,hz,vol,dur) in enumerate([(0,0,220,.037,1.35),(0,.15,330,.03,1.3),(0,.34,440,.022,1.5),(-1,-1.2,220,.035,1.2),(-1,-1.04,330,.027,1.0),(-1,-.89,440,.021,.88)]):
    note((len(timeline)/sr if frame==-1 else 0)+offs,hz,vol,dur)
timeline*=.89/max(.89,abs(timeline).max())
sf.write('public/narration.wav',timeline,sr);Path('timing.json').write_text(json.dumps(scenes,indent=2));print('total',len(timeline)/sr)
