import React from 'react';
import D from './trace.json';
import {C,T,Cap,Rule,Box,Path,Circle,Shield,Lines,DotGrid,Phone,GestureHand,Spark,phase,ease,clamp,mix,pos,rng,pathOf} from './Art';
function NetworkRow({i,y,p}){
 const appear=phase(p,i===0?.02:i===1?.20:.48,i===0?.17:i===1?.34:.61), col=[C.clay,C.fern,C.ink][i];
 const rows=[['Session summary','36 statistics','Residual MLP'],['Motion & swipe','6 signals over time','1D CNN → mean pool'],['Overlapping windows','6 values + 6 presence flags','1D CNN → masked pool']];
 return <g opacity={.28+.72*appear}>
   <g transform={'translate(91 '+(y-33)+')'}>{i===0?rng(7).map((j)=><Box key={j} x={j*9} y={46-(j*13%36)} w={5} h={9+j*13%36} fill={col}/>):i===1?<Spark x={0} y={11} w={64} h={39} values={D.sequence[3].slice(12,32)} col={col}/>:rng(3).map(j=><Box key={j} x={j*13} y={12+j*6} w={38} h={24} col={col} fill={C.paper}/>)}</g>
   <T x={185} y={y-1} size={32} weight={500}>{rows[i][0]}</T><T x={186} y={y+32} size={22} fill={C.muted}>{rows[i][1]}</T>
   <Rule x={530} y={y} x2={592} y2={y} col={col} w={2}/><Box x={592} y={y-37} w={311} h={74} r={7} fill={i===0?'#F1D9C4':i===1?'#D7E5D0':'#E0E6D9'} col={col}/>
   <T x={748} y={y+8} anchor="middle" size={23} weight={550}>{rows[i][2]}</T>
 </g>
}
function Particle({path,t,c}){const pt=pos(path,t%1);return <Circle x={pt[0]} y={pt[1]} r={5} fill={c}/>}
export function Network({p}){
 const top=[[904,353],[976,353],[1069,353],[1151,480]], mid=[[904,490],[970,490],[1017,544]], bot=[[904,628],[970,628],[1017,544]],join=[[1017,544],[1088,544],[1151,480]];
 const paths=[top,mid,bot,join];return <g>
 <Lines x={85} y={175} size={72} lines={['Three views of one transfer']}/>
 <T x={89} y={229} size={26} fill={C.muted}>An encoder turns several kinds of observations into one comparable pattern.</T>
 <Cap x={91} y={286} size={15} fill={C.muted}>INPUT</Cap><Cap x={592} y={286} size={15} fill={C.muted}>LEARNED BRANCH</Cap>
 {[353,490,628].map((y,i)=><NetworkRow key={i} i={i} y={y} p={p}/>)}
 {paths.map((pts,i)=><g key={i}><Path d={pathOf(pts)} col={i===0?C.clay:C.fern} w={2}/>{p>.45&&<Particle path={pts} t={p*4.5+i*.18} c={i===0?C.clay:C.fern}/>}</g>)}
 <Circle x={1017} y={544} r={17} stroke={C.fern} fill={C.cream}/><T x={1017} y={552} anchor="middle" size={25}>+</T>
 <Circle x={1151} y={480} r={8} fill={C.ink}/><Rule x={1159} y={480} x2={1223} y2={480} col={C.ink} w={2}/>
 <Box x={1223} y={391} w={286} h={178} r={10} fill={C.ink}/>
 <Cap x={1247} y={431} size={16} fill={C.mint}>FUSION LAYER</Cap><T x={1243} y={501} size={49} serif fill={C.cream}>256 → 128</T><T x={1248} y={543} size={20} fill={C.sage}>Normalize to unit length</T>
 <Rule x={89} y={729} x2={1508} y2={729}/><T x={90} y={781} size={24} fill={C.muted}>Pooling summarizes the sequence. The window branch averages only windows with observations.</T>
 </g>
}
export function Embedding({p}){
 const revealed=Math.floor(mix(12,128,phase(p,.01,.34))), mx=Math.max(...D.vector.map(Math.abs));const block=52,gap=5;
 const train=phase(p,.47,.81);const cy=720;
 return <g>
 <Cap x={88} y={230} fill={C.mint}>ENCODER OUTPUT</Cap>
 <T x={76} y={383} size={158} serif fill={C.cream} space={-8}>128</T>
 <Lines x={84} y={470} size={68} lines={['numbers,','one session.']} step={78} italicLast fill={C.cream}/>
 <T x={90} y={621} size={25} fill={C.sage}>An embedding gives the transfer</T><T x={90} y={657} size={25} fill={C.sage}>a position in a learned space.</T>
 <Cap x={578} y={214} size={17} fill={C.sage}>EMBEDDING COMPONENTS</Cap><Cap x={1486} y={214} anchor="end" size={16} fill={C.sage}>001 — 128</Cap>
 {D.vector.map((v,i)=>{const x=578+(i%16)*(block+gap),y=241+Math.floor(i/16)*(block+gap),lit=i<revealed;const c=v>=0?C.mint:C.coral;
 return <g key={i}><Box x={x} y={y} w={block} h={block} r={3} fill="#2A433A"/>{lit&&<><Box x={x} y={y} w={block} h={block} r={3} fill={c} opacity={.13+.76*Math.abs(v)/mx}/><Rule x={x+10} y={y+block/2} x2={x+block-10} y2={y+block/2} col="#203B31" opacity={.4}/><Box x={x+17} y={v>=0?y+block/2-Math.max(2,22*Math.abs(v)/mx):y+block/2} w={18} h={Math.max(2,22*Math.abs(v)/mx)} fill={c}/></>}</g>})}
 <T x={578} y={735} size={22} fill={C.sage}>Each tile is one learned value.</T>
 <Circle x={1182} y={729} r={6} fill={C.mint}/><T x={1197} y={736} size={21} fill={C.cream}>Positive</T><Circle x={1320} y={729} r={6} fill={C.coral}/><T x={1335} y={736} size={21} fill={C.cream}>Negative</T>
 {p>.48&&<g opacity={phase(p,.48,.57)}><Rule x={90} y={735} x2={417} y2={735} col="#4D6B5C"/><Circle x={166} y={735} r={9} fill={C.mint}/><Circle x={mix(242,193,train)} y={735} r={9} stroke={C.mint} w={3}/><Circle x={mix(266,391,train)} y={735} r={9} fill={C.coral}/><Cap x={90} y={781} size={14} fill={C.sage}>TRAINING WITH LABELED EXAMPLES</Cap></g>}
 </g>
}
export function Compare({p}){
 const x=480,y=657,r=313;
 const base=[x+r,y];const line=(score,color,progress,name,offset=0)=>{const theta=Math.acos(score),u=phase(p,progress,progress+.18);const ex=x+r*Math.cos(theta)*u,ey=y-r*Math.sin(theta)*u;
 return <g opacity={u}><Path d={'M'+x+' '+y+' L'+ex+' '+ey} w={4} col={color}/><Circle x={ex} y={ey} r={7} fill={color}/><T x={ex+offset} y={ey-21} size={19} fill={color} anchor="middle">{name}</T></g>};
 return <g>
 <Lines x={85} y={176} size={73} lines={['Do the patterns point the same way?']}/>
 <T x={89} y={230} size={26} fill={C.muted}>Cosine similarity measures the angle between two embeddings.</T>
 <DotGrid x={92} y={290} w={785} h={463}/>{[.34,.67,1].map(n=><Path key={n} d={'M'+(x-r*n)+' '+y+' A'+r*n+' '+r*n+' 0 0 1 '+(x+r*n)+' '+y} col="#A7B9A2" w={1.25}/>)}
 <Rule x={x-r-15} y={y} x2={x+r+22} y2={y} col="#A7B9A2"/><Rule x={x} x2={x} y={y} y2={y-r-24} col="#ABB9A7" dash="4 9"/>
 <Path d={'M'+x+' '+y+' L'+base[0]+' '+base[1]} col={C.ink} w={4}/><T x={base[0]} y={y+34} anchor="end" size={19}>This transfer</T>
 {line(D.same,C.fern,.12,'Same operator')}{line(D.other,C.clay,.38,'Another operator') }<Circle x={x} y={y} r={8} fill={C.ink}/>
 <Cap x={92} y={777} size={15} fill={C.muted}>ANGLES RELATIVE TO THIS TRANSFER</Cap>
 <Cap x={975} y={321} size={16} fill={C.muted}>SYNTHETIC EXAMPLE  /  COSINE SCORE</Cap>
 <Rule x={975} y={345} x2={1495} y2={345} col={C.ink}/>
 <T x={969} y={457} size={90} serif fill={C.fern}>{D.same.toFixed(2)}</T><T x={975} y={508} size={26}>Same operator, another session</T>
 <Rule x={975} y={547} x2={1495} y2={547}/>
 <g opacity={.22+.78*phase(p,.38,.52)}><T x={969} y={657} size={90} serif fill={C.clay}>{D.other.toFixed(2).replace('-','−')}</T><T x={975} y={708} size={26}>Different simulated operator</T></g>
 </g>
}
export function MapScene({p}){
 const arr=D.map,here=[D.here.x,D.here.y],all=[...arr,here];const xs=all.map(z=>z[0]),ys=all.map(z=>z[1]);
 const minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys);
 const s=Math.min(780/(maxX-minX),470/(maxY-minY));const pt=([x,y])=>[1063+s*(x-(minX+maxX)/2),495-s*(y-(minY+maxY)/2)];
 const [hx,hy]=pt(here);const total=phase(p,.01,.35);
 const lx=hx>1090?hx-57:hx+57,ly=hy>566?hy-62:hy+61;const anchor=lx<hx?'end':'start';
 return <g>
 <Cap x={87} y={253} fill={C.clay}>ANALYST VIEW</Cap><Lines x={83} y={359} size={74} step={86} lines={['A map of','similar motion.']} italicLast/>
 <T x={89} y={544} size={27}>UMAP lays the embeddings</T><T x={89} y={581} size={27}>out in two dimensions.</T>
 <Rule x={89} y={636} x2={495} y2={636}/><T x={89} y={686} size={22} fill={C.muted}>One dot = one session</T><T x={89} y={726} size={22} fill={C.muted}>Nearby = similar behavior</T>
 <Box x={580} y={167} w={918} h={626} fill="#EAF0DF" col="#BFCCB6" r={10}/><DotGrid x={601} y={212} w={872} h={554}/>
 <Cap x={612} y={212} size={15} fill={C.fern}>FITTED UMAP  /  SYNTHETIC REFERENCE SESSIONS</Cap>
 {arr.map((row,i)=>{const [x,y]=pt(row);const u=ease(clamp(total*1.55-(i%17)/32));return <Circle key={i} x={mix(1063,x,u)} y={mix(495,y,u)} r={5} fill={C.fern} opacity={.57+.27*(i%3)/2}/>})}
 <g opacity={phase(p,.3,.45)}><BurstMap x={hx} y={hy} p={p}/><Path d={'M'+hx+' '+hy+' L'+lx+' '+ly} col={C.clay} w={2}/>
 <Box x={anchor==='start'?lx:lx-172} y={ly-20} w={172} h={37} r={4} fill={C.ink}/><T x={anchor==='start'?lx+86:lx-86} y={ly+5} anchor="middle" size={18} fill={C.cream}>Current session</T></g>
 </g>
}
function BurstMap({x,y,p}){return <g><Circle x={x} y={y} r={19+6*Math.sin(p*20)} stroke={C.clay} w={1.5}/><Circle x={x} y={y} r={7} stroke={C.cream} w={2} fill={C.clay}/></g>}
export function Decision({p}){
 const q=phase(p,.38,.6);return <g>
 <Cap x={88} y={194} fill={C.mint}>TRANSFER REVIEW</Cap>
 <Lines lines={['When the bank needs','one more check.']} x={81} y={302} size={79} step={94} fill={C.cream} italicLast/>
 {['Behavioral match','Physical interaction','Coercion signals'].map((s,i)=><g key={s} opacity={.5+.5*phase(p,.005+i*.08,.17+i*.08)}><Circle x={102} y={503+i*76} r={6} fill={i===0?C.coral:C.mint}/><T x={128} y={512+i*76} size={27} fill={C.cream}>{s}</T><Path d={'M423 '+(503+i*76)+' H472 L530 579'} col="#668876" w={2}/></g>)}
 <Box x={526} y={535} w={236} h={88} r={7} col="#799784" fill="#253E35"/><T x={644} y={588} anchor="middle" size={25} fill={C.cream}>Decision policy</T>
 <Path d="M762 579 H869 L951 499 H1008" col={C.mint} w={2}/><Circle x={mix(762,869,phase(p,.28,.42))} y={579} r={4} fill={C.mint}/>
 <g transform="translate(1017 197) rotate(4 183 271)">
 <Box x={3} y={8} w={375} h={552} r={11} fill="#0D211D"/>
 <path d="M0 0 H375 V536 L362 546 L350 536 L337 546 L324 536 L312 546 L299 536 L286 546 L274 536 L261 546 L248 536 L236 546 L223 536 L210 546 L198 536 L185 546 L172 536 L160 546 L147 536 L134 546 L122 536 L109 546 L96 536 L84 546 L71 536 L58 546 L46 536 L33 546 L20 536 L8 546 L0 536Z" fill={C.paper}/>
 <Shield x={43} y={43} s={.78}/><Cap x={69} y={50} size={16}>SANA PAY</Cap>
 <Rule x={30} y={84} x2={345} y2={84} col="#B6C2AE"/>
 <Cap x={34} y={142} size={16} fill={C.clay}>EXAMPLE DECISION</Cap>
 <g opacity={.27+.73*q}><Lines x={28} y={221} size={48} step={58} lines={['Verify this','transfer.']}/><Box x={32} y={324} w={311} h={56} r={28} fill={C.ink}/><T x={188} y={360} size={21} weight={550} fill={C.cream} anchor="middle">Additional check</T></g>
 <Rule x={31} y={422} x2={344} y2={422} col="#B6C2AE" dash="4 5"/><T x={34} y={462} size={18} fill={C.muted}>Owner baseline still incomplete</T>
 </g>
 <T x={89} y={763} size={23} fill={C.sage}>Owner comparison needs three independently verified enrollment sessions.</T>
 </g>
}

