# The Rhythm of a Transfer

Editable motion graphics for the SANA Shield ML explainer. The illustrations, synthetic trace, English narration, caption timing, and chapter markers are included.

## Preview and export

Install Node.js 22 or later, Python 3, and FFmpeg. In this folder run `npm ci`, then `npm run studio` to preview or `npm run render` to export a captioned MP4. The first Remotion render can download its headless browser.

## Edit the film

The scene order and composition are in `index.jsx`. The drawings and animations are in `Art.jsx`, `Scenes.jsx`, `Transport.jsx`, and `Later.jsx`. The source is authored frame by frame at 24 fps with a 1920 × 1080 output. Each chapter is timed to its recorded narration.

The included model values come from the repository's synthetic-v2 encoder. The exported session is generated profile 2, sample 32. The two comparison sessions are profile 2, sample 31 and profile 3, sample 31. The phone face and gestures are illustrations. The traces, window summaries, neural responses, embedding values, cosine scores and UMAP positions use model data. Map highlights identify the illustrated session. The final receipt illustrates the policy for insufficient owner enrollment.

To regenerate the model data, run `trace_from_repo.py /path/to/ituhack` with the repository's ML Python environment. To change the narration, edit `narrate.py`. It uses local Kokoro ONNX with the v1.0 int8 model saved as `kokoro.onnx`, `voices-v1.0.bin` saved as `voices.bin`, and the af_heart voice. Install kokoro-onnx and soundfile in a separate Python environment. Regenerate edited audio clips, then remove or refresh alignment.json for the new reading. Existing visuals and audio can be rendered without the model, TTS weights, or training data.
