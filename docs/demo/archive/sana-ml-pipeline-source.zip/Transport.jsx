import React from 'react';
import {C,T,Cap,Rule,Box,Path,Circle,Shield,Lines,DotGrid,phase,clamp,mix,rng} from './Art';
function Packet({x,y,fill=C.ink}){
  return <g transform={'translate('+x+' '+y+')'}><Box x={-23} y={-16} w={46} h={32} fill={C.cream} col={fill} r={4} sw={2}/>{[0,1,2].map(i=><Rule key={i} x={-13} y={-7+i*7} x2={i===1?4:13} y2={-7+i*7} col={fill} w={2}/>)}</g>
}
export function Transport({p}){
 const a=phase(p,.12,.44),b=phase(p,.52,.86);
 return <g>
 <Lines x={85} y={178} size={74} lines={['The journey off the phone']}/>
 <T x={90} y={237} size={28} fill={C.muted}>One transfer attempt travels as a single session of observations.</T>
 <DotGrid x={113} y={300} w={1360} h={334}/>
 <Rule x={291} y={466} x2={1303} y2={466} col="#839D87" w={2} dash="5 7"/>
 <g transform="translate(245 468) rotate(-8)"><Box x={-57} y={-104} w={116} h={202} r={17} fill={C.ink}/><Box x={-51} y={-97} w={103} h={184} r={13} fill="#DBE7D2"/><Box x={-13} y={-89} w={24} h={5} r={2} fill={C.ink}/>
 <Shield x={0} y={-49} s={.7}/>{rng(5).map(i=><Box key={i} x={-35+i*13} y={26-(i*5%18)} w={7} h={16+i*5%18} fill={C.fern}/>)}<Box x={-34} y={58} w={67} h={9} r={4} fill={C.sage}/></g>
 <g transform="translate(796 473)"><path d="M-92 -45 L0 -101 L92 -45Z" fill="#C8DCC1" stroke={C.ink} strokeWidth="3"/><Circle x={0} y={-63} r={10} stroke={C.fern} w={2}/>
 {[-63,-21,21,63].map(x=><Box key={x} x={x-8} y={-34} w={16} h={83} r={3} fill={C.paper} col={C.ink} sw={2}/>)}
 <Box x={-87} y={55} w={174} h={11} r={2} fill={C.fern}/><Box x={-99} y={69} w={198} h={11} r={2} fill="#9DB497"/></g>
 <g transform="translate(1323 467)">{[2,1,0].map((n)=><g key={n} transform={'translate('+(-n*9)+' '+(n*13)+')'}><path d="M-83 -41 L0 -82 L82 -41 L0 0 Z" fill={n?'#BDD0B5':'#E7CCAF'} stroke={C.ink} strokeWidth="2"/><path d="M-83 -41 L0 0 L0 23 L-83 -18Z" fill="#92B098" stroke={C.ink} strokeWidth="2"/><path d="M0 0 L82 -41 L82 -18 L0 23Z" fill={C.fern} stroke={C.ink} strokeWidth="2"/>{!n&&rng(4).map(j=><Path key={j} d={'M'+(-40+j*14)+' '+(-35-j*7)+' l38 17'} col={C.clay} w={2}/>)}</g>)}</g>
 {p>.10&&p<.48&&<Packet x={mix(344,685,a)} y={466}/>}
 {p>.49&&p<.92&&<Packet x={mix(907,1205,b)} y={466} fill={C.fern}/>}
 <T x={245} y={645} anchor="middle" size={30} weight={550}>Phone</T><T x={796} y={645} anchor="middle" size={30} weight={550}>Bank backend</T><T x={1318} y={645} anchor="middle" size={30} weight={550}>Identity service</T>
 <T x={245} y={690} anchor="middle" size={23} fill={C.muted}>Collect the session</T><T x={796} y={690} anchor="middle" size={23} fill={C.muted}>Validate and forward</T><T x={1318} y={690} anchor="middle" size={23} fill={C.muted}>Prepare the model inputs</T>
 </g>
}

