import React from 'react';
import D from './trace.json';
import {C,T,Cap,Rule,Box,Path,Circle,Shield,Lines,DotGrid,Phone,GestureHand,Spark,phase,ease,clamp,mix,pos,rng,pathOf} from './Art';
const number=n=>n.toFixed(2);
const WIDTH=1600,HEIGHT=900;
function Arrow({x,y,w=90,col=C.fern}){return <g><Rule x={x} y={y} x2={x+w} y2={y} col={col} w={2}/><Path d={'M'+(x+w-10)+' '+(y-6)+' l10 6 -10 6'} col={col} w={2}/></g>}
function Label({x,y,title,sub,dark=false}){return <g><T x={x} y={y} size={29} weight={550} fill={dark?C.cream:C.ink}>{title}</T><T x={x} y={y+35} size={22} fill={dark?C.sage:C.muted}>{sub}</T></g>}
function Burst({x,y,p,color=C.coral}){return <g>{rng(3).map((i)=>{const c=(p+i/3)%1;return <Circle key={i} x={x} y={y} r={12+52*c} stroke={color} w={2} opacity={(1-c)*.62}/>})}</g>}
export function Opening({p}){
  return <g>
    <Circle x={1115} y={450} r={337} fill="#DEE6D1"/><Circle x={1115} y={450} r={311} stroke="#BECCB6" w={1.5} strokeDasharray="4 10"/>
    {rng(36).map(i=><g key={i} transform={'rotate('+(10*i)+' 1115 450)'}><Rule x={1115} x2={1115} y={123} y2={i%3?129:136} col="#81957E"/></g>)}
    <g transform={'translate(1068 439) rotate(-9) scale(1.05)'}><Phone p={clamp(p*1.15)}/></g>
    <Cap x={88} y={214} fill={C.clay}>BEHAVIORAL IDENTITY</Cap>
    <Lines lines={['Recognize','a swipe?']} x={80} y={350} size={105} step={121} italicLast/>
    <Rule x={90} y={539} x2={595} y2={539} col={C.ink}/>
    <T x={90} y={600} size={33}>One simulated transfer.</T><T x={90} y={646} size={33}>One behavioral pattern.</T>
    <g transform="translate(92 740)">{rng(42).map(i=><Rule key={i} x={i*5} y={0} x2={i*5} y2={-8-Math.abs(D.vector[i])*155} col={i%8===0?C.coral:C.fern} w={2.7}/>)}</g>
  </g>
}
export function Capture({p}){
  const run=phase(p,.01,.83), t=D.duration*run;
  const X=655,W=798,Y=[360,518,676];const at=t=>X+W*t/D.duration;
  const data=D.motion.filter(([ms])=>ms<=t);
  const last=D.keys.reduce((a,k)=>k[0]<=t?k:a,D.keys[0]); const dwell=Math.round(last[1]-last[0]);
  const progressKeys=D.keys.filter(k=>k[0]<=t).length;
  return <g>
    <Lines x={86} y={180} size={70} lines={['The phone records the rhythm']}/>
    <T x={89} y={235} size={27} fill={C.muted}>Tap duration, swipe position and motion over time.</T>
    <Circle x={293} y={510} r={182} fill="#E3E8D6"/><DotGrid x={103} y={327} w={378} h={370}/>
    <g transform="translate(254 505) rotate(-8) scale(.66)"><Phone p={run}/></g>
    <Cap x={93} y={785} size={16} fill={C.muted}>KINETIQ SDK  /  PHONE</Cap>
    {['Key contact','Swipe position','Phone motion'].map((a,i)=><g key={a}><T x={X} y={Y[i]-47} size={24} weight={550}>{a}</T><Rule x={X} y={Y[i]+35} x2={X+W} y2={Y[i]+35} col="#B7C6B2"/></g>)}
    {rng(4).map(i=><g key={i}><Rule x={at(i*1000)} y={311} x2={at(i*1000)} y2={721} dash="3 9" col="#B0BDAA"/><Cap x={at(i*1000)} y={762} size={17}>{i} s</Cap></g>)}
    {D.keys.filter(([d])=>d<t).map(([d,u],i)=><Box key={i} x={at(d)} y={Y[0]+3} w={Math.max(1,at(Math.min(u,t))-at(d))} h={32} fill={C.fern} r={4}/>)}
    <Path d={pathOf(D.swipe.filter(k=>k[0]<=t).map(v=>[at(v[0]),Y[1]+40-v[1]*83]))} col={C.clay} w={5}/>
    <Path d={pathOf(data.map(v=>[at(v[0]),Y[2]+21-95*v[1]]))} col={C.fern} w={3}/>
    <Rule x={at(t)} y={299} x2={at(t)} y2={725} col={C.clay} w={2}/>
    <T x={1451} y={313} size={18} mono anchor="end" fill={C.muted}>{progressKeys?dwell+' ms dwell':'Waiting for touch'}</T>
  </g>
}
export function Windows({p}){
  const next=phase(p,.43,.58);
  const X=151,W=1185,at=t=>X+W*t/4000,Y=419;const win=next<.5?0:1;
  const vals=D.windows[win];const labels=['Key dwell','Contact dwell','Pressure','Motion','Swipe speed','Key interval'];const fields=['key_dwell','contact_dwell','pressure','motion','travel','key_interval'];
  const A=next*1000;
  return <g>
    <Lines lines={['Two seconds at a time']} x={84} y={187} size={78}/>
    <T x={90} y={243} size={28} fill={C.muted}>Each window shares one second with its neighbor.</T>
    <Cap x={X} y={316} size={16} fill={C.fern}>SESSION TIME</Cap>
    <Box x={at(A)} y={345} w={at(2000)-at(0)} h={167} r={6} fill="#DBE9CF" col={C.fern} sw={2.5}/>
    {next>.04&&<Box x={at(1000)} y={349} w={at(2000)-at(1000)} h={159} fill="url(#absent)" opacity={next*.34}/>}
    <T x={at(A)+18} y={378} size={21} weight={550}>{'Window '+(win+1)}</T>
    {rng(5).map(i=><g key={i}><Rule x={at(i*1000)} y={394} x2={at(i*1000)} y2={524} col="#A5B49E" dash="3 7"/><Cap x={at(i*1000)} y={554} anchor="middle" size={17}>{i} s</Cap></g>)}
    <Path d={pathOf(D.motion.map(v=>[at(v[0]),Y+61-140*v[1]]))} col={C.fern} w={3}/>
    {D.keys.map(([a,b],i)=><Box key={i} x={at(a)} y={Y-17} w={at(b)-at(a)} h={18} r={3} fill={C.clay}/>)}
    <Rule x={at(D.duration)} y={390} x2={at(D.duration)} y2={522} col={C.ink}/>
    <Cap x={1420} y={483} anchor="middle" size={13} fill={C.muted}>END</Cap>
    <Cap x={151} y={625} size={16} fill={C.muted}>SIX NORMALIZED SIGNALS IN THIS WINDOW</Cap>
    {fields.map((field,i)=>{const v=vals[field],x=151+i*222;return <g key={field}>
      <Rule x={x} y={653} x2={x+192} y2={653} col={C.ink}/><T x={x} y={696} size={23}>{labels[i]}</T>
      <T x={x} y={757} mono size={v==null?24:36} fill={v==null?C.muted:C.fern}>{v==null?'Missing':v.toFixed(3)}</T>
    </g>})}
  </g>
}
export function Kernel({p}){
  const scan=phase(p,.04,.94), n=64;const cursor=clamp(.07+.85*scan);const x=480,y=350,w=974;
  const t=D.sequence[3], idx=Math.round(cursor*(n-1));const center=x+idx*w/63;
  const lo=Math.min(...t),hi=Math.max(...t);
  return <g>
    <Cap x={90} y={219} fill={C.mint}>INSIDE THE NETWORK</Cap>
    <Lines x={84} y={322} size={62} step={78} lines={['One filter','slides along.']} fill={C.cream} italicLast/>
    <T x={90} y={511} size={25} fill={C.sage}>A 1D convolution reads</T><T x={90} y={547} size={25} fill={C.sage}>neighboring moments.</T>
    <DotGrid x={477} y={240} w={1000} h={480} dark/>
    <Box x={x} y={y-46} w={w} h={151} r={3} fill="#213F35"/>
    <Cap x={x} y={y-77} size={17} fill={C.sage}>ONE INPUT CHANNEL  /  ACCELERATION</Cap>
    <Spark values={t} x={x+1} y={y-22} w={w-2} h={94} col={C.mint} stroke={3.5}/>
    <Box x={center-2.1*w/63} y={y-49} w={4.2*w/63} h={158} fill="#E99D6E" opacity={.20}/>
    <Box x={center-2.1*w/63} y={y-49} w={4.2*w/63} h={158} col={C.coral} sw={2}/>
    {rng(5).map(j=>{const k=idx-2+j;return <Circle key={j} x={x+k*w/63} y={y-22+94*(1-(t[k]-lo)/(hi-lo||1))} r={5} fill={C.coral}/>})}
    <Path d={'M'+(center-30)+' '+(y+113)+' L'+center+' '+(y+151)+' L'+(center+30)+' '+(y+113)} col={C.coral} w={1.6}/>
    <Cap x={x} y={y+188} size={16} fill={C.sage}>LEARNED RESPONSES  /  FOUR CHANNELS SHOWN</Cap>
    {D.act.slice(0,4).map((v,i)=><g key={i} opacity={.55+.45*phase(p,.14+i*.04,.24+i*.04)}><Rule x={x} y={y+230+i*49} x2={x+w} y2={y+230+i*49} col="#3B5B4F"/><Spark values={v} x={x} y={y+207+i*49} w={w} h={34} col={i%2?C.sage:C.coral} reveal={.10+.90*scan}/></g>)}
    <Cap x={x} y={776} size={16} fill={C.sage}>EARLIER</Cap><Cap x={x+w} y={776} anchor="end" size={16} fill={C.sage}>LATER →</Cap>
  </g>
}

