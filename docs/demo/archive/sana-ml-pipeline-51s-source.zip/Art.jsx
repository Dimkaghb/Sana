import React from 'react';
import trace from './trace.json';
export const C={paper:'#F5F1E5', cream:'#FFF9EB', ink:'#192F2B', ink2:'#223D35', muted:'#576D60', sage:'#ADC5A0', fern:'#42785D', mint:'#CBECBB', coral:'#E77A4C', clay:'#AC4728', fine:'#C5CEC0', deep:'#152B29'};
export const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
export const ease=v=>{v=clamp(v);return v*v*(3-2*v)};
export const phase=(p,a,b)=>ease((p-a)/(b-a));
export const mix=(a,b,u)=>a+(b-a)*u;
export const pos=(points,u)=>{let i=Math.min(points.length-2,Math.floor(clamp(u)*(points.length-1))),v=clamp(u)*(points.length-1)-i;return points[i].map((x,j)=>mix(x,points[i+1][j],v));};
export const rng=n=>Array.from({length:n},(_,i)=>i);
export const T=({x,y,size=26,children,fill=C.ink,weight=400,serif=false,mono=false,italic=false,anchor='start',space=0,...rest})=><text x={x} y={y} fill={fill} fontSize={size} fontWeight={weight} fontStyle={italic?'italic':'normal'} fontFamily={serif?'Georgia, serif':mono?'Menlo, monospace':'Helvetica Neue, Arial, sans-serif'} textAnchor={anchor} letterSpacing={space} {...rest}>{children}</text>;
export const Cap=({children,...props})=><T size={18} mono space={1.6} {...props}>{children}</T>;
export const Rule=({x,y,x2,y2,col=C.fine,w=1.5,dash,opacity=1})=><line x1={x} y1={y} x2={x2} y2={y2} stroke={col} strokeWidth={w} strokeDasharray={dash} opacity={opacity} />;
export const pathOf=pts=>pts.map(([x,y],i)=>(i?'L':'M')+x.toFixed(2)+' '+y.toFixed(2)).join(' ');
export const Path=({d,col=C.ink,w=3,fill='none',...rest})=><path d={d} fill={fill} stroke={col} strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" {...rest}/>;
export const Circle=({x,y,r,fill='none',stroke='none',w=1,...rest})=><circle cx={x} cy={y} r={r} fill={fill} stroke={stroke} strokeWidth={w} {...rest}/>;
export const Box=({x,y,w,h,fill='none',col='none',r=0,sw=1.6,...rest})=><rect x={x} y={y} width={w} height={h} rx={r} fill={fill} stroke={col} strokeWidth={sw} {...rest}/>;
export const DotGrid=({x,y,w,h,dark=false})=><rect x={x} y={y} width={w} height={h} fill={'url(#dots'+(dark?'D':'L')+')'} />;
export function Defs(){return <defs>
  {['L','D'].map((s)=><pattern key={s} id={'dots'+s} patternUnits="userSpaceOnUse" width="21" height="21"><circle cx="1" cy="1" r="1" fill={s==='D'?'#416052':'#A3B29E'}/></pattern>)}
  <pattern id="etch" patternUnits="userSpaceOnUse" width="9" height="9" patternTransform="rotate(30)"><path d="M0 0 V9" stroke="#914D38" strokeWidth="2" opacity=".45"/></pattern>
  <pattern id="weave" patternUnits="userSpaceOnUse" width="8" height="8"><path d="M0 1 H8 M1 0 V8" stroke="#FAAD7A" strokeWidth="1" opacity=".5"/></pattern>
  <pattern id="absent" patternUnits="userSpaceOnUse" width="9" height="9" patternTransform="rotate(40)"><path d="M0 0 V9" stroke="#9AAB97" strokeWidth="2"/></pattern>
  <linearGradient id="skin" x1="0" y1="0" x2="1" y2=".7" gradientUnits="objectBoundingBox"><stop stopColor="#F8C295"/><stop offset=".6" stopColor="#EAA77C"/><stop offset="1" stopColor="#CB815F"/></linearGradient>
  <linearGradient id="glass" x2=".65" y2="1"><stop stopColor="#FAF6E9"/><stop offset="1" stopColor="#E0E9D8"/></linearGradient>
  </defs>}
export function Shield({x,y,s=1,c=C.ink}){return <g transform={'translate('+x+' '+y+') scale('+s+')'}><Path d="M0 -13 Q10 -8 14 -8 V2 Q14 12 0 19 Q-14 12 -14 2 V-8 Q-8 -9 0 -13Z" col={c} w={2}/><Path d="M-6 2 L-1 7 L7 -2" col={c} w={2.4}/></g>}
export function Lines({lines,x,y,size=70,step=size*1.13,fill=C.ink,italicLast=false}){return lines.map((s,i)=><T key={i} x={x} y={y+i*step} size={size} serif fill={fill} italic={italicLast&&i===lines.length-1} space={-2.2}>{s}</T>)}
export const GestureHand=({x,y,scale=1,angle=0,press=0})=>{
  const contour='M-12 13 C-29 -9 -13 -32 6 -30 C17 -29 27 -20 36 -10 L148 103 C151 77 172 69 187 79 L203 94 C209 73 231 70 246 83 L266 101 C278 84 299 87 310 104 L352 169 Q389 215 401 265 L429 331 L281 395 L248 337 C225 315 201 304 183 289 C151 267 120 246 101 220 L65 171 C55 156 57 142 68 134 C81 125 94 130 107 143 L139 174 L132 155 Z';
  return <g transform={'translate('+x+' '+y+') rotate('+angle+') scale('+scale+')'}>
  <path d={contour} transform="translate(7 10)" fill="#563A27" opacity=".12"/>
  <Path d={contour} fill="url(#skin)" col="#573F34" w={2.8}/>
  <path d="M111 215 Q170 267 221 285 Q270 305 288 350 L280 376 L251 333 Q178 288 143 262Z" fill="url(#etch)"/>
  <Path d="M-6 -17 Q6 -26 19 -12 L30 0 Q17 16 5 14 L-7 0 Q-12 -9 -6 -17Z" fill="#F9D5B6" col="#AD735E" w={1.65}/>
  <Path d="M145 105 Q173 126 188 154 M202 95 Q231 116 246 143 M265 103 Q287 118 301 142 M131 155 Q145 169 152 188 M66 148 Q72 144 79 149 L92 164 Q86 171 78 169 M55 53 Q65 47 74 47 M61 61 Q72 55 79 55 M97 100 Q108 93 119 93 M170 186 Q179 200 181 214 M201 186 Q210 200 211 211" col="#A6674D" w={2}/>
  <path d="M248 331 Q324 301 396 259 L477 360 L316 444Z" fill={C.coral} stroke="#573F34" strokeWidth="3"/>
  <path d="M248 331 Q324 301 396 259 L477 360 L316 444Z" fill="url(#weave)"/>
  <Path d="M262 350 Q341 321 410 277" col="#8C4734" w={2.5}/>
  </g>
};
export function Phone({p,small=false,final=false}){
  const time=clamp(p)*trace.duration;
  const keys=trace.keys, count=keys.length;
  const pads=[[-73,13],[0,13],[73,13],[73,57],[0,57],[-73,57],[-73,101],[0,101],[73,101]];
  let n=keys.findLastIndex(([down])=>down<=time);
  n=Math.max(0,n);
  const following=Math.min(n+1,count-1), shift=phase(time,keys[n][1],keys[following][0]>keys[n][1]?keys[following][0]:keys[n][1]+1);
  const cell=[mix(pads[n][0],pads[following][0],shift),mix(pads[n][1],pads[following][1],shift)];
  const slider=trace.swipe;
  const swipe=clamp((time-slider[0][0])/(slider[slider.length-1][0]-slider[0][0]));
  const move=phase(time,keys[count-1][1],slider[0][0]);
  const gx=mix(cell[0],-88+157*swipe,move), gy=mix(cell[1],166,move);
  const press=time>=keys[n][0]&&time<=keys[n][1]||time>=slider[0][0]&&time<=slider[slider.length-1][0]?1:0;
  return <g>
    <ellipse cx="26" cy="251" rx="171" ry="24" fill="#53654C" opacity=".13"/>
    <Box x={-151} y={-253} w={302} h={522} r={36} fill="#607668" col={C.ink} sw={4}/>
    <Box x={-155} y={-260} w={302} h={522} r={36} fill="#284037" col={C.ink} sw={4}/>
    <Box x={-144} y={-248} w={280} h={497} r={29} fill="url(#glass)" col="#132E26" sw={2}/>
    <Box x={-151} y={-132} w={-1+4} h={56} fill={C.ink}/><Box x={146} y={-119} w={4} h={55} r={2} fill={C.ink}/>
    <Box x={-36} y={-236} w={65} h={10} r={5} fill={C.ink}/>
    <Shield x={-104} y={-183} s={.8}/><Cap x={-80} y={-177} size={13}>SANA PAY</Cap>
    <Rule x={-119} y={-152} x2={112} y2={-152}/>
    <T x={-119} y={-116} size={17} fill={C.muted}>Demo transfer</T><T x={-120} y={-68} size={37} weight={550}>100 000 ₸</T>
    <Rule x={-119} y={-45} x2={112} y2={-45}/>
    {rng(9).map(i=>{const x=(i%3-1)*73,y=17+Math.floor(i/3)*44;return <g key={i}><Box x={x-29} y={y-19} w={58} h={34} r={9} fill="#F9F8ED" col="#C6D2C1"/><T x={x} y={y+3} size={16} anchor="middle">{i+1}</T></g>})}
    <Box x={-117} y={142} w={224} h={48} r={24} fill="#BFD7B9"/><Box x={-112} y={147} w={45+154*swipe} h={38} r={19} fill={C.fern}/>
    <T x={-89+154*swipe} y={173} size={20} anchor="middle" fill={C.cream}>{swipe>.97?'✓':'→'}</T>
    <Box x={-40} y={227} w={78} h={4} r={2} fill="#5E7665"/>
    <Circle x={gx} y={gy} r={18+13*press} stroke={C.coral} w={2} opacity={.12+.65*press}/>
    <GestureHand x={gx+2} y={gy-1} scale={.8+press*.025} angle={-12}/>
  </g>
}
export function Spark({values,x,y,w,h,col=C.fern,stroke=3,reveal=1,min,max}){
  const lo=min??Math.min(...values),hi=max??Math.max(...values);
  const pts=values.map((v,i)=>[x+w*i/(values.length-1),y+h-h*(v-lo)/(hi-lo||1)]);
  const n=Math.max(1,Math.ceil(clamp(reveal)*pts.length));
  return <Path d={pathOf(pts.slice(0,n))} col={col} w={stroke}/>;
}

