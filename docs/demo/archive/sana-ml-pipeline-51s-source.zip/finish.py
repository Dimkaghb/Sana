"""Mux the illustrated film, narration, English captions, and chapter markers."""
import argparse
import difflib
import json
from pathlib import Path
import re
import subprocess
import textwrap

FPS = 24
CHAPTERS = ["The gesture", "Capturing signals", "Sliding windows", "A learned filter",
            "The encoder", "The embedding", "Similarity", "The population map", "The decision"]


def clock(seconds):
    ms = max(0, round(seconds * 1000))
    return f"{ms // 3600000:02}:{ms // 60000 % 60:02}:{ms // 1000 % 60:02},{ms % 1000:03}"


def normalized(word):
    return re.sub(r"[^a-z0-9]", "", word.lower())


def caption_chunks(words):
    start = 0
    while start < len(words):
        end = start + 1
        while end < len(words):
            if len(" ".join(words[start:end+1])) > 74:
                break
            if end-start >= 5 and re.search(r"[.,!?;:]$", words[end-1]):
                break
            end += 1
        if len(words)-end <= 2 and len(" ".join(words[start:])) <= 78:
            end = len(words)
        yield start, end
        start = end


def make_tracks():
    timings = json.loads(Path("timing.json").read_text())
    alignment = Path("alignment.json")
    observed = json.loads(alignment.read_text()) if alignment.exists() else []
    caps = []
    marks = [";FFMETADATA1", "title=Recognize a Swipe?", "artist=SANA Shield"]
    frames = 0
    for title, scene in zip(CHAPTERS, timings):
        origin = frames/FPS
        frames += scene["frames"]
        marks.extend(["[CHAPTER]", "TIMEBASE=1/1000", f"START={round(origin*1000)}",
                      f"END={round(frames/FPS*1000)}", "title="+title])
        for cue in scene["cues"]:
            lo, hi = origin+cue["start"], origin+cue["end"]
            words = cue["text"].split()
            actual = [w for w in observed if lo-.10 <= (w["start"]+w["end"])/2 <= hi+.10]
            anchors = {0: lo, len(words): hi}
            match = difflib.SequenceMatcher(None, list(map(normalized,words)),
                                            [normalized(w["word"]) for w in actual], autojunk=False)
            for a,b,n in match.get_matching_blocks():
                for i in range(n):
                    if a+i:
                        anchors[a+i] = max(lo,min(hi,actual[b+i]["start"]))
            def time(index):
                if index in anchors:
                    return anchors[index]
                a = max(k for k in anchors if k < index)
                b = min(k for k in anchors if k > index)
                weight = sum(len(w)+1 for w in words[a:index])/sum(len(w)+1 for w in words[a:b])
                return anchors[a]+(anchors[b]-anchors[a])*weight
            for a,b in caption_chunks(words):
                lines = textwrap.wrap(" ".join(words[a:b]), width=42, break_long_words=False, break_on_hyphens=False)
                caps.append(f"{len(caps)+1}\n{clock(time(a))} --> {clock(time(b))}\n"+"\n".join(lines))
    Path("english.srt").write_text("\n\n".join(caps)+"\n")
    Path("chapters.ffmeta").write_text("\n".join(marks)+"\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("output")
    args = parser.parse_args()
    make_tracks()
    subprocess.run(["ffmpeg","-y","-v","error","-i","visual.mp4","-i","public/narration.wav",
                    "-i","english.srt","-f","ffmetadata","-i","chapters.ffmeta",
                    "-map","0:v:0","-map","1:a:0","-map","2:s:0","-map_metadata","3","-map_chapters","3",
                    "-c:v","copy","-af","loudnorm=I=-14:TP=-1.5:LRA=9","-ar","48000","-c:a","aac","-b:a","160k",
                    "-c:s","mov_text","-metadata:s:s:0","language=eng","-metadata:s:a:0","language=eng",
                    "-disposition:s:0","0","-movflags","+faststart",args.output],check=True)

