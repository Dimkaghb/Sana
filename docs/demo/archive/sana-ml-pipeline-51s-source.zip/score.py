"""Record the short narration and mix its original percussion and plucked notes."""
import json
import os
from pathlib import Path
import numpy as np
import soundfile as sf
from kokoro_onnx import Kokoro

lines = [
    "Could you recognize someone by the way they swipe? Sana Shield looks for that rhythm.",
    "The phone measures tap timing, swipe movement, and available sensor signals. This recording leaves out the digits you type.",
    "The bank sends the session to its identity service. Two-second windows advance one second at a time.",
    "A one-dimensional convolution scans for short patterns, like a burst of movement.",
    "The encoder combines the motion trace, the window measurements, and statistics from the whole session.",
    "The result is an embedding: one hundred and twenty-eight numbers describing how this transfer was made.",
    "These two sessions from the same simulated user score point nine seven. A different user's session scores minus point two six.",
    "On the map, each dot is one session. Similar movements tend to land close together.",
    "Different people can move alike. The bank weighs other evidence before asking for another check."
]
fps, sr = 24, 24000
dir = Path(os.environ.get('KOKORO_MODEL_DIR','.'))
tts = Kokoro(str(dir/'kokoro.onnx'),str(dir/'voices.bin'))
parts, scenes = [], []
for i,line in enumerate(lines):
    voice, rate = tts.create(line, voice='af_heart', speed=1.17, lang='en-us')
    assert rate == sr
    bounds=np.flatnonzero(np.abs(voice)>.00075)
    voice=voice[max(0,bounds[0]-600):min(len(voice),bounds[-1]+1100)]
    lead=.12 if i else .18
    tail=.15 if i<len(lines)-1 else .67
    frames=int(np.ceil((lead+len(voice)/sr+tail)*fps))
    a=np.zeros(round(frames*sr/fps)); start=round(lead*sr);a[start:start+len(voice)]=voice
    parts.append(a);scenes.append(dict(frames=frames,cues=[dict(start=lead,end=lead+len(voice)/sr,text=line)]))
    print(i,frames/fps,flush=True)
audio=np.concatenate(parts); starts=np.r_[0,np.cumsum([s['frames'] for s in scenes])[:-1]]/fps
rng=np.random.default_rng(234); length=len(audio)/sr
def layer(t,kind,freq,vol,dt):
    left=round(t*sr);n=min(len(audio)-left,round(sr*dt))
    if n<1:return
    x=np.arange(n)/sr; env=np.minimum(1,x/.005)*np.minimum(1,(dt-x)/.025)
    if kind=='pluck':
        wave=(np.sin(2*np.pi*freq*x)+.26*np.sin(4*np.pi*freq*x))*np.exp(-x*7/dt)
    elif kind=='pulse':
        wave=np.sin(2*np.pi*(freq*x+2*(1-np.exp(-x*19))))*np.exp(-x*6/dt)
    else:
        noise=rng.normal(0,.35,n);wave=(noise-np.r_[0,noise[:-1]])*np.exp(-x*8/dt)
    audio[left:left+n]+=vol*env*wave
beat=60/118
for i,t in enumerate(np.arange(.18,length-1,beat)):
    if i%4 in (0,2):layer(t,'pulse',82.4,.036,.16)
    if i%2:layer(t,'tick',0,.016,.055)
    if i%4 in (0,3):layer(t+beat/2,'pluck',[196,246.94,293.66,329.63][(i//4+i%4)%4],.024,.25)
for i,t in enumerate(starts):
    layer(t+.04,'pluck',[392,493.88,587.33][i%3],.04,.31)
def cue(scene_id,u,k,f,v,d):
    layer(starts[scene_id]+scenes[scene_id]['frames']/fps*u,k,f,v,d)
for frac in [.13,.29,.43,.57]:cue(0,frac,'tick',0,.047,.07)
cue(2,.52,'tick',0,.05,.08)
for j in range(3):cue(5,.10+j*.045,'pluck',[392,493.88,587.33][j],.048,.44)
layer(length-.61,'pluck',329.63,.043,.60)
sf.write('public/narration.wav',audio*.94/max(.94,np.max(np.abs(audio))),sr)
Path('timing.json').write_text(json.dumps(scenes,indent=2))
print('Duration',length)
