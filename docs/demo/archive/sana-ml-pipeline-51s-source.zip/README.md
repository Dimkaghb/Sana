# Recognize a Swipe?

A 51-second narrated SANA Shield explainer. The Remotion source includes original illustrations, a locally voiced English script, an original 118 BPM percussion track, chapter markers, captions, and timing. The data and graphics in this example use synthetic sessions.

## Preview and render

Install Node.js 22+, FFmpeg and Python 3. Run `npm ci`, then `npm run studio` to preview or `npm run render` to export the MP4. The first render may download the Remotion headless browser.

## Edit

Edit the drawings in Art.jsx, Scenes.jsx and Later.jsx. Adjust the cut in index.jsx and timing.json. The bundled audio in public/narration.wav contains the finished mix. To change the narration or percussion, score.py uses kokoro-onnx and soundfile. Set KOKORO_MODEL_DIR to the directory containing kokoro.onnx (Kokoro v1.0 int8) and voices.bin (v1.0 voice bank). Refresh or remove alignment.json after revoicing so captions follow the new recording.

The real model outputs for the synthetic examples are in trace.json. trace_from_repo.py regenerates them using the project's ML Python environment. For this film we used synthetic profile 2, sample 32, and compared its embedding with sample 31 from profiles 2 and 3. The closing receipt illustrates an additional identity check.
