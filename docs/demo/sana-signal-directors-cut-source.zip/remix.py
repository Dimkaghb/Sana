"""Add the director's stereo transition cues to the original voice and score."""
import json
from pathlib import Path
import numpy as np
import soundfile as sf

voice, rate = sf.read("narration.wav")
stereo = np.column_stack([voice, voice])
rng = np.random.default_rng(12)
timing = json.loads(Path("timing.json").read_text())
starts = np.r_[0, np.cumsum([shot["frames"] for shot in timing]) / 24]
for shot in (2, 3, 5, 7, 8):
    start = round((starts[shot] - .24) * rate)
    n = round(rate * .29)
    t = np.arange(n) / rate
    envelope = np.sin(np.pi * np.arange(n) / (n - 1)) ** 3
    noise = np.convolve(rng.normal(0, 1, n), np.ones(8) / 8, "same")
    sweep = .032 * (.6 * noise + .4 * np.sin(2 * np.pi * (180 * t + 950 * t * t))) * envelope
    pan = np.linspace(.2, .8, n)
    stereo[start:start+n, 0] += sweep * (1-pan)
    stereo[start:start+n, 1] += sweep * pan
sf.write("public/mix.wav", stereo * .94 / max(.94, abs(stereo).max()), rate)
