"""Export only the synthetic example used for the illustrations."""
import argparse
import json
from pathlib import Path
import sys

parser = argparse.ArgumentParser()
parser.add_argument("repo", type=Path)
args = parser.parse_args()
root = args.repo.resolve()
sys.path.insert(0, str(root))

import torch
from contracts.windows import sliding_windows
from ml.encoder import tensors
from ml.features import extract
from ml.seed_population import session
from ml.train import load

encoder, projector, manifest = load(root / "ml/artifacts/synthetic-v2")
current = session(2, 32)
features = extract(current)
vec, same, different = encoder.embed([features, extract(session(2, 31)), extract(session(3, 31))])
with torch.inference_mode():
    _, sequence, _ = tensors([features])
    sequence = ((sequence-encoder.seq_center)/encoder.seq_scale).nan_to_num().clamp(-5, 5)
    activation = encoder.temporal(sequence.transpose(1, 2))[0]
trace = {
    "duration": current["duration_ms"],
    "keys": [[k["down_ms"], k["up_ms"]] for k in current["keystrokes"]],
    "swipe": [[p["t_ms"], p["x_norm"], p["y_norm"], p["pressure"]] for p in current["slider_trace"]],
    "motion": [[p["t_ms"], p["az"]] for p in current["imu_samples"]],
    "windows": sliding_windows(current),
    "vector": vec.tolist(),
    "sameVector": same.tolist(),
    "otherVector": different.tolist(),
    "same": float(vec @ same),
    "other": float(vec @ different),
    "act": activation[:10].tolist(),
    "sequence": sequence[0].T.tolist(),
    "map": projector.coordinates.tolist(),
    "here": projector.point(vec),
    "model": manifest["id"],
}
Path(__file__).with_name("trace.json").write_text(json.dumps(trace))

