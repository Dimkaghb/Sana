import React from 'react';
import D from './trace.json';
import {C,clamp,phase,mix,range,curve,rect,line,path,dot,Txt,Tag,Head,Emblem,Pulse} from './Design';
export const encoderPoint=p=>{
 const pts=[[480,496],[570,496],[625,486],[859,523],[918,496],[956,496],[1056,480],[1261,480],[1320,480]];
 const u=phase(p,.02,.89)*(pts.length-1), i=Math.min(pts.length-2,Math.floor(u));
 return pts[i].map((v,j)=>mix(v,pts[i+1][j],u-i));
};
export const embedPoint=p=>{
 const k=D.vector.indexOf(Math.max(...D.vector)),v=D.vector[k],c=k%16-7.5,r=Math.floor(k/16)-3.5;
 const ang=mix(-.07,.09,phase(p,.01,.97)),rx=c*Math.cos(ang)-r*Math.sin(ang),ry=c*Math.sin(ang)+r*Math.cos(ang);
 const height=4+149*Math.abs(v)/Math.max(...D.vector.map(Math.abs))*phase(p,.02+k*.0017,.26+k*.0028);
 return [1083+31*rx-30*ry,533+12*rx+19*ry-height];
};
export const matchPoint=p=>[1477,mix(487,676,phase(p,.5,.6))];

const mapExtent=(()=>{
 const pts=[...D.map,[D.here.x,D.here.y]],xs=pts.map(v=>v[0]),ys=pts.map(v=>v[1]);
 return {x:(Math.min(...xs)+Math.max(...xs))/2,y:(Math.min(...ys)+Math.max(...ys))/2,s:Math.min(770/(Math.max(...xs)-Math.min(...xs)),492/(Math.max(...ys)-Math.min(...ys)))};
})();
const mapTo=(x,y)=>[1062+(x-mapExtent.x)*mapExtent.s,470-(y-mapExtent.y)*mapExtent.s];
export const mapPoint=p=>{const [x,y]=mapTo(D.here.x,D.here.y);return [mix(1040,x,phase(p,0,.39)),mix(481,y,phase(p,0,.39))]};
export const decisionPoint=p=>[mix(89,1327,phase(p,.25,.77)),mix(706,572,phase(p,.25,.77))];

function Wafer({x,y,i,p}){
 const tint=[C.peri,C.acid,'#75D9DE'][i], pulse=phase(p,.08+i*.115,.30+i*.115);
 const top='M-147 -8 L-82 -42 H118 L152 -8 L85 28 H-107Z';
 return <g transform={'translate('+x+' '+y+')'}>
 {path('M-147 -8 L-107 28 H85 L152 -8 V8 L86 45 H-107 L-147 9Z','#79A1D5',1.35,'#183A61')}
 {path(top,'#9DBEE3',1.55,'#244970')}
 {range(7).map(j=><g key={j}>{line(-121+j*26,4,-69+j*26,-25,'#668AAD',1.4)}</g>)}
 {path('M-147 -8 L-107 28 H85 L152 -8',tint,2.4)}
 {rect(-68,-22,158,35,'#142C49',6)}
 <Txt x={11} y={2} s={19} wt={600} c={tint} align="middle">{['Residual MLP','Trace CNN','Window CNN'][i]}</Txt>
 <g opacity={pulse}><Pulse x={87} y={28} col={tint} r={4}/></g>
 </g>
}
export function Encoder({p}){
 const inputs=['Session statistics','Motion & swipe','Overlapping windows'];
 return <g>
 <Head x={75} y={205} lines={['Three views. One encoder.']} s={86}/>
 {inputs.map((title,i)=>{const yy=350+i*146;const cc=[C.peri,C.acid,'#75D9DE'][i];return <g key={title}>
 <Txt x={84} y={yy} s={37} wt={530} track={-1.5}>{title}</Txt><Tag x={86} y={yy+42} s={16} c={C.mute}>{['36 SESSION STATISTICS','6 TIME-SERIES CHANNELS','6 VALUES + 6 PRESENCE FLAGS'][i]}</Tag>
 {path('M480 '+yy+' H569 L622 '+(yy-10),cc,1.9)}
 <Wafer x={767} y={yy} i={i} p={p}/>
 {path('M918 '+yy+' H956 Q976 '+yy+' 991 '+(yy+(i===0?18:i===2?-18:0))+' L1056 480',cc,2)}
 </g>})}
 {dot(1056,480,8,C.acid)}{line(1056,480,1261,480,C.acid,2)}
 <g transform="translate(1320 480)"><ellipse rx={75} ry={107} fill="#102A47" stroke="#87A2C5" strokeWidth="2"/>{range(9).map(i=><ellipse key={i} cx={i*2-10} rx={65-i*4} ry={94-i*4} fill="none" stroke={i===7?C.acid:'#4C708D'} strokeWidth="1.5"/>)}</g>
 <Tag x={1321} y={656} align="middle" c={C.peri}>FUSION</Tag>
 <Txt x={85} y={782} s={24} c={C.mute}>The two CNN branches read across time. Fusion combines their patterns with the session summary.</Txt>
 </g>
}
function block(x,y,h,w,d,positive,opacity){
 const top=positive?'#DAFF58':'#9FC1FF',left=positive?'#7EAB35':'#4B76BB',right=positive?'#4B731F':'#30578E';
 const pts=[[x,y-d],[x+w,y],[x,y+d],[x-w,y]];
 return <g opacity={opacity}>{path(curve([[x-w,y-h],[x,y+d-h],[x,y+d],[x-w,y]])+'Z','#223C64',.75,left)}
 {path(curve([[x,y+d-h],[x+w,y-h],[x+w,y],[x,y+d]])+'Z','#223C64',.75,right)}
 {path(curve(pts.map(([a,b])=>[a,b-h]))+'Z','#314F72',.85,top)}</g>
}
export function Embedding({p}){
 const max=Math.max(...D.vector.map(Math.abs));
 const angle=mix(-.07,.09,phase(p,.01,.97));const cos=Math.cos(angle),sin=Math.sin(angle);
 let blocks=D.vector.map((v,i)=>{const c=i%16-7.5,r=Math.floor(i/16)-3.5,rx=c*cos-r*sin,ry=c*sin+r*cos;
   return {i,v,x:1083+31*rx-30*ry,y:533+12*rx+19*ry};
 }).sort((a,b)=>a.y-b.y);
 const reveal=phase(p,.06,.64);
 return <g>
 <Tag x={83} y={220} c={C.peri}>ONE SESSION EMBEDDING</Tag>
 <Txt x={65} y={458} s={212} wt={620} track={-18}>{Math.round(128*reveal)}</Txt>
 <Txt x={84} y={541} s={65} wt={540} track={-3.5}>coordinates.</Txt>
 <Txt x={88} y={626} s={27} c={C.peri}>Together they describe how</Txt><Txt x={88} y={663} s={27} c={C.peri}>the transfer was made.</Txt>
 {path('M697 535 L927 357 L1486 554 L1263 753Z','#77A5ED',1.7,'#193963')}
 {blocks.map(({i,v,x,y})=>{const u=phase(p,.02+i*.0017,.26+i*.0028);return <g key={i}>{block(x,y,4+Math.abs(v)/max*149*u,24,12,v>=0,.35+.65*u)}</g>})}
 <Tag x={747} y={797} s={16} c={C.peri}>HEIGHT = MAGNITUDE</Tag>{dot(1115,790,6,C.acid)}<Txt x={1131} y={798} s={20}>Positive</Txt>{dot(1265,790,6,'#A3C5FF')}<Txt x={1281} y={798} s={20}>Negative</Txt>
 </g>
}
function Ribbon({x,y,vec,w=562,bright}){
 const seg=w/vec.length;
 return <g>{line(x,y,x+w,y,'#A2B4C5',1)}{vec.map((v,i)=>{const h=Math.max(2,Math.abs(v)*218);return <g key={i}>{rect(x+i*seg,v>0?y-h:y,seg*.78,h,v>=0?(bright?'#48742A':'#4B7292'):(bright?'#8C9DC5':'#879AB9'),1)}</g>})}</g>
}
export function Compare({p}){
 const flip=phase(p,.45,.59);
 return <g>
 <Tag x={82} y={142} c={C.ash}>COSINE SIMILARITY  /  TWO SYNTHETIC COMPARISONS</Tag>
 <Head x={72} y={253} s={91} c={C.ink} lines={['How close is this session?']}/>
 <Txt x={83} y={353} c={C.ash} s={24}>Compare the 128 values with another session’s embedding.</Txt>
 <Tag x={576} y={387} s={14} c={C.ash}>CURRENT SESSION ABOVE  /  COMPARISON BELOW</Tag>
 {line(82,399,1513,399,'#A1B4C5')}
 {[0,1].map(i=>{const y=497+i*183,v=i===0?D.same:D.other,vec=i===0?D.sameVector:D.otherVector;return <g key={i} opacity={i?.36+.64*flip:1}>
 <Txt x={84} y={y} s={39} c={C.ink} wt={560} track={-1.6}>{i?'Different operator':'Same operator'}</Txt>
 <Tag x={87} y={y+38} s={15} c={C.ash}>{i?'DIFFERENT SIMULATED PROFILE':'SEPARATE SIMULATED SESSION'}</Tag>
 <Ribbon x={576} y={y-12} vec={D.vector}/><Ribbon x={576} y={y+48} vec={vec} bright/>
 <Txt x={1432} y={y+28} s={87} wt={550} track={-5} align="end" c={i?'#5D7392':'#355C1E'}>{v.toFixed(2).replace('-','−')}</Txt>
 {line(82,y+95,1513,y+95,'#BCBBC4')}
 </g>})}
 </g>
}
export function MapScene({p}){
 const [hx,hy]=mapPoint(p);const at=phase(p,.025,.48);
 const projected=D.map.map(([x,y])=>mapTo(x,y));
 return <g>
 <Tag x={83} y={240} c={C.peri}>POPULATION MAP</Tag>
 <Head x={73} y={361} s={80} step={83} lines={['One dot,','one session.']} italicLast/>
 <Txt x={81} y={554} s={28} c={C.mute}>Nearby dots suggest</Txt><Txt x={81} y={596} s={28} c={C.mute}>similar movements.</Txt>
 <Tag x={83} y={740} s={17}>UMAP  /  2D PROJECTION</Tag>
 {rect(596,154,898,611,'url(#grid)',8)}
 {projected.map(([x,y],i)=>{const u=phase(at,(i%14)*.014,.79+(i%5)*.04),xx=mix(880+(i%16)*18,x,u),yy=mix(361+Math.floor(i/16)*19,y,u);
 return <g key={i}>{dot(xx,yy,4.5,i%3===0?'#D0DCED':'#84A6D5')}</g>})}
 {p>.42&&<g opacity={phase(p,.42,.55)}>{dot(hx,hy,17+Math.sin(p*28)*3,'none',C.acid,1.4)}
 {path('M'+hx+' '+hy+' l40 -38 h117',C.acid,1.8)}<Txt x={hx+45} y={hy-49} s={19} c={C.acid}>This session</Txt></g>}
 </g>
}
export function Decision({p}){
 const ok=phase(p,.52,.76),flag=phase(p,.38,.65);
 return <g>
 <Tag x={83} y={205} c={C.peri}>SIMULATED TRANSFER DECISION</Tag>
 <Head x={71} y={338} s={88} step={100} lines={['Similar movement','is one clue.']} italicLast/>
 <Txt x={84} y={560} s={28} c={C.mute}>The bank also checks physical interaction</Txt><Txt x={84} y={602} s={28} c={C.mute}>and signals of possible coercion.</Txt>
 {['Identity','Interaction','Coercion'].map((v,i)=><g key={v} opacity={.6+.4*phase(p,.02+i*.13,.22+i*.13)}>{dot(89,706+34*i,5,[C.acid,C.peri,'#75D9DE'][i])}<Txt x={109} y={713+i*34} s={19} c={C.mute}>{v}</Txt></g>)}
 <g transform={'translate(1200 457) rotate('+mix(-7,-2,ok)+')'}>
 {rect(-216,-280,432,561,'url(#metal)',49)}{rect(-209,-275,417,548,C.deep,45)}{rect(-200,-264,399,526,'#E7EDEB',38)}{rect(-43,-251,86,15,C.navy,8)}
 <Emblem x={-153} y={-183} c={C.ink} s={.63}/><Txt x={-124} y={-176} s={23} c={C.ink} wt={600}>SANA Pay</Txt>
 {line(-164,-136,162,-136,'#ACBBC3')}
 <Tag x={-165} y={-80} s={15} c={C.ash}>EXAMPLE OUTCOME</Tag>
 <Head x={-169} y={-16} lines={['Verify this','transfer.']} s={53} step={57} c={C.ink}/>
 {rect(-162,93,322,61,'#244463',30)}
 <Txt x={-1} y={132} s={22} wt={540} align="middle" c={C.ice}>Additional check</Txt>
 <Txt x={-163} y={203} s={16} c={C.ash}>Owner history is still incomplete.</Txt>
 {rect(-48,241,96,4,'#7D91A7',2)}
 </g>
 </g>
}

