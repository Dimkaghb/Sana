import React,{useEffect} from 'react';
import {AbsoluteFill,Composition,registerRoot,useCurrentFrame,Html5Audio,staticFile,delayRender,continueRender,cancelRender} from 'remotion';
import {C,clamp,phase,mix,interp,range,rect,line,path,dot,Txt,Tag,Emblem,Pulse,Defs} from './Design';
import {Cover,Capture,Windows,Kernel,heroPoint,capturePoint,windowPoint,kernelPoint} from './Signals';
import {Encoder,Embedding,Compare,MapScene,Decision,encoderPoint,embedPoint,matchPoint,mapPoint,decisionPoint} from './Identity';
import timing from './timing.json';
const shots=[Cover,Capture,Windows,Kernel,Encoder,Embedding,Compare,MapScene,Decision];
const targets=[heroPoint,capturePoint,windowPoint,kernelPoint,encoderPoint,embedPoint,matchPoint,mapPoint,decisionPoint];
const looks=['midnight','midnight','cobalt','midnight','midnight','cobalt','chalk','midnight','midnight'];
const names=['THE GESTURE','THE RECORDING','SLIDING WINDOWS','1D CONVOLUTION','ENCODER FUSION','THE EMBEDDING','MATCHING','THE MAP','THE DECISION'];
const ends=timing.map((s,i)=>timing.slice(0,i+1).reduce((a,b)=>a+b.frames,0));
const end=ends.at(-1);
function ensureFaces(){useEffect(()=>{const handle=delayRender('Loading bundled type');Promise.all(['normal','italic'].map(async style=>{
 const face=new FontFace('FilmGeist','url('+staticFile('fonts/geist-latin-wght-'+style+'.woff2')+')',{style,weight:'100 900'});
 document.fonts.add(await face.load());
})).then(()=>continueRender(handle)).catch(cancelRender);},[])}
function Sheet({i,p,opacity=1}){
 const Shot=shots[i], light=looks[i]==='chalk';
 return <g opacity={opacity}>{rect(0,0,1600,900,'url(#'+looks[i]+')')}
 <g><Emblem x={97} y={64} s={.65} c={light?C.ink:C.ice}/><Txt x={124} y={71} s={24} wt={650} c={light?C.ink:C.ice} track={-.9}>SANA Shield</Txt>
 <Tag x={1512} y={69} align="end" s={15} c={light?C.ash:C.mute}>BEHAVIORAL IDENTITY</Tag></g>
 <Shot p={p}/>
 {line(82,835,1516,835,light?'#9EAFBA':'#3D546F',1)}
 <Tag x={83} y={864} s={14} c={light?C.ash:C.mute}>{names[i]}</Tag>
 {range(9).map(j=><g key={j}>{rect(1228+j*32,851,24,3,j<i?(light?'#426332':C.peri):(light?'#B3C3CC':'#40526B'),1.4)}{j===i&&rect(1228+j*32,850,Math.max(2,p*24),5,light?'#588120':C.acid,2)}</g>)}
 </g>
}
function Film(){
 ensureFaces();
 const f=useCurrentFrame(),i=Math.max(0,ends.findIndex(e=>f<e)),start=i?ends[i-1]:0,local=f-start,p=local/(timing[i].frames-1),n=Math.min(i+1,8);
 const handoff=i===8?0:phase(local,timing[i].frames-9,timing[i].frames-1);
 const from=targets[i](p),to=targets[n](0),xy=interp(from,to,handoff);
 const pulseColor=i===6&&handoff<.5?'#42622B':C.acid;
 return <AbsoluteFill style={{background:C.navy}}><Html5Audio src={staticFile('mix.wav')}/>
 <svg width="100%" height="100%" viewBox="0 0 1600 900" style={{display:'block'}}>
 <Defs/><Sheet i={i} p={p}/>{handoff>0&&<Sheet i={n} p={0} opacity={handoff}/>}
 {handoff>.02&&handoff<.99&&path('M'+mix(from[0],xy[0],.79)+' '+mix(from[1],xy[1],.79)+' L'+xy[0]+' '+xy[1],pulseColor,2,'none',{opacity:Math.sin(handoff*Math.PI)*.57})}
 <Pulse x={xy[0]} y={xy[1]} r={i===0?6:5.2} col={pulseColor} intensity={i===8?1-phase(p,.87,.99):1}/>
 </svg></AbsoluteFill>
}
const Root=()=> <Composition id="Signal" component={Film} width={1920} height={1080} fps={24} durationInFrames={end}/>;
registerRoot(Root);

