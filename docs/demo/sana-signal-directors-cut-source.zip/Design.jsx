import React from 'react';
export const C={navy:'#091422',deep:'#060F1B',night:'#122744',steel:'#537498',blue:'#4C80FF',peri:'#A8C8FF',ice:'#EAF2FF',mute:'#A8BCD5',acid:'#DAFF48',amber:'#FCB78B',paper:'#F0F3ED',ink:'#152F44',ash:'#577080'};
export const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
export const ease=v=>{v=clamp(v);return v*v*(3-2*v)};
export const phase=(p,a,b)=>ease((p-a)/(b-a));
export const mix=(a,b,u)=>a+(b-a)*u;
export const range=n=>Array.from({length:n},(_,i)=>i);
export const curve=pts=>pts.map(([x,y],i)=>(i?'L':'M')+x.toFixed(2)+','+y.toFixed(2)).join(' ');
export const interp=(a,b,u)=>a.map((v,i)=>mix(v,b[i],u));
export const rect=(x,y,w,h,fill,r=0,stroke='none',sw=1)=><rect x={x} y={y} width={w} height={h} rx={r} fill={fill} stroke={stroke} strokeWidth={sw}/>;
export const line=(x1,y1,x2,y2,c,w=1,dash)=><line {...{x1,x2,y1,y2}} stroke={c} strokeWidth={w} strokeDasharray={dash}/>;
export const path=(d,c,w=2,fill='none',more={})=><path d={d} fill={fill} stroke={c} strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" {...more}/>;
export const dot=(x,y,r,fill,stroke='none',w=1)=><circle cx={x} cy={y} r={r} {...{fill,stroke}} strokeWidth={w}/>;
export function Txt({x,y,s=27,c=C.ice,wt=450,mono=false,italic=false,align='start',track=0,children}){
 return <text x={x} y={y} fontFamily={mono?'Menlo, monospace':'FilmGeist, Arial, sans-serif'} fontStyle={italic?'italic':'normal'} fontWeight={wt} fontSize={s} fill={c} textAnchor={align} letterSpacing={track}>{children}</text>
}
export function Tag({x,y,children,c=C.mute,s=18,align='start'}){return <Txt x={x} y={y} c={c} s={s} align={align} mono track={1.4}>{children}</Txt>}
export function Head({x=86,y=203,lines,s=80,step=83,c=C.ice,italicLast=false}){
 return lines.map((word,i)=><Txt key={i} x={x} y={y+step*i} s={s} wt={590} c={c} track={-.065*s} italic={italicLast&&i===lines.length-1}>{word}</Txt>)
}
export function Emblem({x,y,s=.86,c=C.ice}){return <g transform={'translate('+x+' '+y+') scale('+s+')'}>{path('M-17 -14 Q-7 -14 0 -20 Q8 -14 17 -14 V0 C17 13 7 19 0 24 C-9 18 -17 11 -17 0Z',c,2.8)}{path('M-8 1 L-2 7 L9 -6',c,3)}</g>}
export function Pulse({x,y,r=5,col=C.acid,intensity=1}){
 return <g opacity={intensity}>{<circle cx={x} cy={y} r={r*4.7} fill={col} opacity=".065"/>}<circle cx={x} cy={y} r={r*2.4} fill={col} opacity=".13"/>{dot(x,y,r,col)}{dot(x-r*.1,y-r*.1,r*.37,'#FFFFEA')}</g>
}
export function Defs(){return <defs>
 <radialGradient id="midnight" cx="74%" cy="39%" r="90%"><stop stopColor="#25436C"/><stop offset=".49" stopColor="#102237"/><stop offset="1" stopColor="#060D16"/></radialGradient>
 <radialGradient id="cobalt" cx="67%" cy="34%" r="90%"><stop stopColor="#3868D3"/><stop offset=".65" stopColor="#163B8F"/><stop offset="1" stopColor="#102653"/></radialGradient>
 <radialGradient id="chalk" cx="75%" cy="30%" r="90%"><stop stopColor="#FFFFFF"/><stop offset="1" stopColor="#DCE5E5"/></radialGradient>
 <linearGradient id="metal" x1="0%" y1="100%" x2="90%" y2="0%"><stop stopColor="#465D77"/><stop offset=".18" stopColor="#C1D7EB"/><stop offset=".35" stopColor="#46607B"/><stop offset=".58" stopColor="#C7D9EA"/><stop offset=".68" stopColor="#6685A9"/><stop offset="1" stopColor="#213448"/></linearGradient>
 <linearGradient id="glass" x2="70%" y2="100%"><stop stopColor="#274F83"/><stop offset=".55" stopColor="#133454"/><stop offset="1" stopColor="#091E34"/></linearGradient>
 <linearGradient id="person" x2="65%" y2="95%"><stop stopColor="#FFE3C7"/><stop offset=".45" stopColor="#F4BB94"/><stop offset="1" stopColor="#AD705B"/></linearGradient>
 <pattern id="knit" width="8" height="8" patternUnits="userSpaceOnUse"><path d="M0 0 L8 8 M-4 4 L0 8 M4 0L8 4" stroke="#AFCEF9" opacity=".3" strokeWidth="1"/></pattern>
 <pattern id="grid" width="49" height="49" patternUnits="userSpaceOnUse"><path d="M49 0 H0 V49" fill="none" stroke="#A1BEDE" opacity=".12" strokeWidth="1"/><circle cx="0" cy="0" r="2" fill="#CFDFF2" opacity=".3"/></pattern>
 <pattern id="cross" width="28" height="28" patternUnits="userSpaceOnUse"><path d="M1 3 H5 M3 1 V5" stroke="#6587A6" opacity=".32" strokeWidth="1"/></pattern>
 </defs>}
export function Finger({x,y,angle=0,scale=.9}){
 const d='M-14 11 C-27 -4 -17 -23 -5 -27 C9 -33 20 -26 35 -16 L139 63 C147 40 166 36 182 45 L201 57 C214 39 230 40 248 52 L266 68 C280 56 291 60 306 73 L354 127 Q390 158 414 217 L448 279 L329 375 L280 311 Q249 296 221 281 L165 255 Q132 235 109 206 L69 158 C61 147 68 131 78 127 C89 122 101 128 109 137 L143 164 L132 143Z';
 return <g transform={'translate('+x+' '+y+') rotate('+angle+') scale('+scale+')'}>
 <path d={d} fill="#081320" opacity=".23" transform="translate(5 14)"/>
 {path(d,'#684F48',2.6,'url(#person)')}
 {path('M-8 -17 C0 -25 9 -25 19 -17 L30 -8 Q25 7 8 9 L-5 -1 Q-12 -7 -8 -17Z','#AC7D6A',1.6,'#FAD8C5')}
 {path('M140 65 Q166 82 183 103 M201 58 Q220 73 238 96 M265 68 Q278 77 298 103 M136 143 Q148 157 152 174 M70 146 Q80 132 91 145 L100 156 Q91 169 84 167 M59 39 Q68 34 77 34 M65 47 Q73 43 82 41 M104 79 Q113 73 122 71','#A56D56',2)}
 {path('M274 314 L414 215 L512 360 L377 458Z','#102744',3,'#3863A6')}{path('M274 314 L414 215 L512 360 L377 458Z','none',0,'url(#knit)')}
 {path('M291 332 L428 236','#8BAED9',3)}
 </g>
}
export function Phone({swipe=0}){
 const shift=swipe*179;
 return <g>
 {rect(-172,-283,344,565,'url(#metal)',54,'#20394E',3)}
 {rect(-176,-291,343,561,'#96AAC3',51,'#E3EBF3',2)}
 {rect(-172,-287,336,553,'#0B131E',48)}
 {rect(-161,-275,312,527,'url(#glass)',39)}
 {rect(-39,-261,75,14,'#07121F',9)}{rect(162,-101,5,64,'#829AB5',2)}
 <Emblem x={-121} y={-192} s={.58}/><Txt x={-95} y={-184} s={18} wt={600}>SANA Pay</Txt>
 {line(-131,-153,123,-153,'#7995B0',1)}
 <Tag x={-130} y={-100} s={14}>DEMO TRANSFER</Tag>
 <Txt x={-132} y={-43} s={42} wt={600} track={-2}>100 000 ₸</Txt>
 <g opacity=".48">{range(10).map(i=><g key={i}>{line(-129+i*27,-12,-129+i*27,-4,'#B1C3D7',1)}</g>)}</g>
 <Txt x={-128} y={63} s={19} c={C.mute}>Slide to confirm</Txt>
 {rect(-130,93,253,70,'#0C1B2D',35,'#65819D',1.4)}
 {rect(-124,99,59+shift,58,'#CBEF42',29)}
 {path('M'+(-107+shift)+' 128 h20 m-8 -8 8 8 -8 8',C.ink,2.5)}
 {rect(-44,232,85,5,'#8FA2BD',3)}
 </g>
}

