# The Shape of a Swipe

An editable 51-second SANA Shield film directed using Motion Video Director. A traveling lime marker links the finger, recorded trace, model, matching score, projected map point and simulated transfer decision.

## Preview and export

Use Node 22+, FFmpeg and Python 3. Run `npm ci`, then `npm run studio` for the preview or `npm run render` for a captioned 1920 × 1080 MP4. The first render may download its headless browser. The voice, mixed audio, timing, font and model data are bundled.

## Scenes

Design.jsx contains the phone, illustrated hand, typography and rendering primitives. Signals.jsx follows the gesture, trace, windows and filter. Identity.jsx draws the fusion branches, 128-component graphic, similarity comparison, UMAP and final receipt. index.jsx handles the camera handoffs and shared signal marker. The illustrations explain model behavior. The traces, neural responses, comparison vectors and UMAP coordinates come from the synthetic-v2 encoder. The example amounts and closing receipt illustrate a simulated transfer.

## Sound and data

The finished English narration and score are in public/mix.wav. To revoice, run score.py using kokoro-onnx, numpy and soundfile, with KOKORO_MODEL_DIR pointing to the v1.0 int8 model and voice bank. Then run remix.py to apply the stereo transition accents. Refresh alignment.json for revised speech or remove it to estimate caption boundaries from the timed lines. Run trace_from_repo.py with the repository ML environment and the ituhack repository path to regenerate the model data.

## Credits

The motion drawings and sound design are original to this film. The voice uses the Kokoro af_heart model voice. Geist is bundled under the SIL Open Font License in public/fonts/LICENSE. The Motion Video Director reference reel informed the motion study. All on-screen footage is drawn for SANA Shield.
