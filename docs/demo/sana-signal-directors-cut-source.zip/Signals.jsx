import React from 'react';
import D from './trace.json';
import {C,clamp,ease,phase,mix,range,curve,rect,line,path,dot,Txt,Tag,Head,Emblem,Finger,Phone,Pulse} from './Design';
const tx=t=>425+t/D.duration*1075;
const time=p=>D.duration*phase(p,.018,.94);
const heroU=p=>phase(p,.11,.83);
export function heroPoint(p){const x=-99+179*heroU(p);return [1049+.97*x+.37*128,410-.27*x+.92*128]}
export function capturePoint(p){const ms=time(p);const i=Math.min(D.motion.length-1,Math.floor(ms/D.duration*(D.motion.length-1)));return [tx(ms),635-D.motion[i][1]*110]}
export const windowPoint=p=>[178+(2000+1000*phase(p,.49,.71))/4000*1160,451];
export const kernelPoint=p=>[370+1070*(.07+.86*phase(p,.03,.89)),390];

export function Cover({p}){
 const [fx,fy]=heroPoint(p);
 return <g>
 {range(22).map(i=>{const pts=range(94).map(j=>{const u=j/93,x=415+1240*u;return[x,688+i*9-315*Math.sin(u*3.4+.8+i*.019)+42*Math.cos(u*8-p*1.8+i*.033)]});return <g opacity={.13+.17*i/22} key={i}>{path(curve(pts),'#639EEC',1.4)}</g>})}
 <g transform="matrix(.97 -.27 .37 .92 1049 410)">{rect(-149,-249,340,555,'#07111C',53)}<Phone swipe={heroU(p)}/></g>
 <Finger x={fx+6} y={fy-7} angle={-15} scale={.97}/>
 <Tag x={81} y={217} c={C.peri}>BEHAVIORAL IDENTITY</Tag>
 <Head x={70} y={383} lines={['The shape','of a swipe.']} s={122} step={125} italicLast/>
 {line(82,585,508,585,'#849DB7')}
 <Txt x={82} y={640} s={30} c={C.mute}>One simulated transfer,</Txt><Txt x={82} y={681} s={30} c={C.mute}>from touch to decision.</Txt>
 </g>
}
export function Capture({p}){
 const t=time(p), rows=[325,490,635];const stop=tx(t);
 return <g>
 <Head x={74} y={212} s={87} lines={['Your timing leaves a trace.']}/>
 {rect(419,251,1095,471,'url(#grid)',8)}
 {['Tap timing','Swipe travel','Phone motion'].map((s,i)=><g key={s}><Txt x={80} y={rows[i]+1} s={35} wt={520} track={-1.2}>{s}</Txt><Tag x={81} y={rows[i]+36} s={16} c={C.mute}>{['KEY DOWN / UP','POSITION','ACCELERATION'][i]}</Tag>{line(425,rows[i]+25,1500,rows[i]+25,'#466282',1)}</g>)}
 {D.keys.filter(([d])=>d<t).map(([d,u],i)=><g key={i}>{rect(tx(d),rows[0]-20,Math.max(1,tx(Math.min(t,u))-tx(d)),45,C.peri,3)}</g>)}
 {path(curve(D.swipe.filter(v=>v[0]<=t).map(v=>[tx(v[0]),rows[1]+29-76*v[1]])),C.ice,5)}
 {path(curve(D.motion.filter(v=>v[0]<=t).map(v=>[tx(v[0]),635-110*v[1]])),C.acid,3.5)}
 {line(stop,277,stop,704,C.acid,1.2,'5 6')}
 {range(4).map(i=><Tag x={tx(1000*i)} y={760} c={C.peri} s={17} key={i}>{i}.0 s</Tag>)}
 <Tag x={81} y={788} s={17}>SYNTHETIC SESSION</Tag>
 </g>
}
export function Windows({p}){
 const step=phase(p,.49,.71),xa=178+290*step,xb=xa+580,sel=step<.5?0:1;
 return <g>
 <Tag x={80} y={151} c={C.peri}>BANK BACKEND   →   IDENTITY SERVICE</Tag>
 <Head x={74} y={255} s={82} lines={['Read two seconds at a time.']}/>
 <g>{rect(105,358,1389,183,'#091E3E',8)}
 {rect(xa,349,580,202,'#3C5B70',5,'#D6FB52',2)}
 {rect(xa+10,359,560,182,'url(#grid)')}
 {step>.05&&<g opacity={step*.34}>{rect(468,360,290,178,'#BDD76E')}</g>}
 {range(41).map(i=><g key={i}>{line(178+i*29,535,178+i*29,i%10===0?559:546,'#9CAECD',i%10===0?2:1)}</g>)}
 {path(curve(D.motion.map(v=>[178+v[0]/4000*1160,480-v[1]*145])),C.ice,3.5)}
 {D.keys.map(([a,b],i)=><g key={i}>{rect(178+a/4000*1160,386,(b-a)/4000*1160,14,C.acid,2)}</g>)}
 {range(5).map(i=><Tag key={i} x={178+290*i} y={591} align="middle" s={17} c={C.ice}>{i} s</Tag>)}
 {line(xa,326,xb,326,C.acid,1.8)}{line(xa,319,xa,332,C.acid,2)}{line(xb,319,xb,332,C.acid,2)}
 <Txt x={xa+290} y={311} align="middle" s={23} c={C.acid} wt={600}>2 s window</Txt></g>
 <Tag x={177} y={700} c={C.peri}>WINDOW {sel+1}</Tag>
 <Txt x={177} y={753} s={35} wt={500}>{sel?'1.0 – 3.0 s':'0.0 – 2.0 s'}</Txt>
 {line(541,672,541,765,'#6E8CC3')}
 <Txt x={596} y={713} s={28}>Move forward one second.</Txt><Txt x={596} y={754} s={26} c={C.peri}>Half the window overlaps the previous read.</Txt>
 </g>
}
export function Kernel({p}){
 const [cx]=kernelPoint(p), min=Math.min(...D.sequence[3]),max=Math.max(...D.sequence[3]);const X=370,W=1070;
 const scan=phase(p,.03,.89);const actual=D.sequence[3];
 return <g>
 <Tag x={80} y={156} c={C.peri}>TEMPORAL ENCODER</Tag><Head x={73} y={251} s={83} lines={['A filter moves through time.']}/>
 <Txt x={81} y={396} s={34} wt={500}>Input trace</Txt><Tag x={81} y={435} s={16}>ACCELERATION</Tag>
 {line(X,390,X+W,390,'#46617C')}
 {path(curve(actual.map((v,i)=>[X+i/63*W,441-(v-min)/(max-min)*92])),C.ice,3.5)}
 {rect(cx-41,324,82,139,'#D9FF491F',2,C.acid,2.2)}
 <path d={'M'+(cx-41)+' 466 L'+(cx-9)+' 508 h18 L'+(cx+41)+' 466'} stroke={C.acid} fill="none" strokeWidth="1.5"/>
 <Txt x={80} y={595} s={34} wt={500}>Responses</Txt><Tag x={81} y={636} s={16}>LEARNED CHANNELS</Tag>
 {D.act.slice(0,8).map((arr,i)=>{const lo=Math.min(...arr),hi=Math.max(...arr),Y=571+i*24,dx=i*5;const pts=arr.map((v,k)=>[X+dx+k*(W-42)/63,Y-(v-lo)/(hi-lo||1)*34]);
 return <g key={i}>{path(curve(pts)+' L'+(X+dx+W-42)+' '+(Y+12)+' L'+(X+dx)+' '+(Y+12)+'Z','none',0,i%2?'#182E49':'#142B46')}{path(curve(pts),i%2?'#81A0D2':'#4973AA',1.5)}{path(curve(pts.slice(0,Math.ceil((.08+.9*scan)*64))),i<2?C.acid:C.peri,i===0?3:1.6)}</g>})}
 <Tag x={1438} y={795} align="end" s={16}>TIME  →</Tag>
 </g>
}

