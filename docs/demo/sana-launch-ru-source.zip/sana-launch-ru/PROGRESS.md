# SANA Shield · Один перевод

The 51-second Russian launch film is complete. The master is SANA-Shield-Launch-RU.mp4. It contains 1,530 H.264 frames at 1920 × 1080 and 30 fps, stereo Russian AAC at 48 kHz and optional Russian subtitles. The export passed a full decode. The encoded audio measured −16.0 LUFS integrated and −1.6 dBTP.

The film follows the synthetic dictation transfer from the repository. The phone, receipt and Guardian inserts were captured from the local application in fixture mode. The rhythm uses the nine recorded key-down times. Motion and overlapping windows come from the same fixture. The activations and the 128-component embedding were computed from that fixture using the local synthetic-v2 checkpoint. The scripted hold follows the saved policy evidence for the fixture.

The score and sound effects were composed for this cut. The Russian narration uses the Xenia voice from Silero v4_ru. The opening phone photograph was created with ImageGen. Manrope is distributed under the SIL Open Font License, included in assets/FONT-LICENSE.txt.

The original reference studios hosted the local reference files. ObiN Studio published the full 93-second Numtera film. Zelios published a 3.2-second LangEase portfolio excerpt. The two YouTube downloads requested sign-in, and the full Vimeo player for LangEase also required verification. The reference videos were used for visual study. Every shot in the launch film is original to the project.

## Sources

- Silero Team, [Silero Models](https://github.com/snakers4/silero-models#licence), v4_ru.
- [Numtera, ObiN Studio](https://obinstudio.com/work/numtera)
- [LangEase, Zelios](https://zelios.agency/cases/langease-launch-video-ad/)
