const cv=document.getElementById('film'), c=cv.getContext('2d',{alpha:false});
const W=1280,H=720,A={}, dark='#101e19', deep='#092219', paper='#f2f2e9', soft='#a1b7aa', ink='#14261d', green='#98e2b1', amber='#f8c782';
let D, peakAz;
const clamp=(n,a=0,b=1)=>Math.max(a,Math.min(b,n)), ease=n=>1-Math.pow(1-clamp(n),3);
const prm=(t,a,b)=>clamp((t-a)/(b-a)), lerp=(a,b,t)=>a+(b-a)*t;
function rect(x,y,w,h,color,r=0){c.fillStyle=color;c.beginPath();c.roundRect(x,y,w,h,r);c.fill();}
function path(points,color,weight=1){if(points.length<2)return;c.strokeStyle=color;c.lineWidth=weight;c.lineJoin='round';c.lineCap='round';c.beginPath();points.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.stroke();}
function dot(x,y,r,color){c.fillStyle=color;c.beginPath();c.arc(x,y,r,0,Math.PI*2);c.fill();}
function txt(str,x,y,size,weight=500,color=ink,align='left',spacing=0){c.save();c.font=weight+' '+size+'px Manrope, Arial, sans-serif';c.fillStyle=color;c.textAlign=align;c.textBaseline='alphabetic';c.letterSpacing=spacing+'px';c.fillText(str,x,y);c.restore();}
function faded(alpha,fn){c.save();c.globalAlpha*=clamp(alpha);fn();c.restore();}
function bg(a,b){const g=c.createLinearGradient(0,0,W,H);g.addColorStop(0,a);g.addColorStop(1,b);rect(0,0,W,H,g);}
function shield(x,y,s,col,progress=1){
 c.save();c.translate(x,y);c.scale(s,s);c.strokeStyle=col;c.lineWidth=2.3;c.lineCap='round';c.lineJoin='round';
 const p=new Path2D('M 16 2 C 20 5 24 7 29 7 L 29 18 C 29 24 24 29 16 33 C 8 29 3 24 3 18 L 3 7 C 8 7 12 5 16 2 Z');
 c.setLineDash([104*clamp(progress),110]);c.stroke(p);c.setLineDash([]);if(progress>.53)faded((progress-.53)*3,()=>path([[10,17],[14,21],[22,13]],col,2.5));c.restore();
}
function pic(im,x,y,w,h,r=0){c.save();c.beginPath();c.roundRect(x,y,w,h,r);c.clip();c.drawImage(im,x,y,w,h);c.restore();}
function smallBrand(x,y,col){shield(x,y-23,.78,col);txt('SANA Shield',x+38,y,23,680,col,'left',-.7);}
function intro(t){
 const z=1+.027*ease(t/3);c.drawImage(A.hero,0,0,A.hero.width,A.hero.height,-W*(z-1)*.65,-H*(z-1)*.5,W*z,H*z);
 faded(ease((t+.08)/.7),()=>{smallBrand(77,91,'#e7f4e8');txt('Один перевод.',71,420,82,560,'#f1f5ec','left',-3.5);});
}
function device(x,y,w,t){
 const h=w*1.92;
 c.save();c.translate(x,y);c.rotate(-.028+.014*ease(t/5));
 c.shadowColor='#203f363d';c.shadowBlur=30;c.shadowOffsetY=15;rect(0,0,w,h,'#26312e',w*.115);c.shadowBlur=0;c.shadowOffsetY=0;
 rect(2,2,w-4,h-4,'#839188',w*.112);rect(5,5,w-10,h-10,'#101713',w*.105);
 rect(11,11,w-22,h-22,'#fff',w*.091);rect(w*.36,18,w*.28,15,'#101713',9);
 pic(A.transfer,13,47,w-26,(w-26)*A.transfer.height/A.transfer.width,14);
 c.restore();
}
function transfer(t){
 const u=t-3;bg('#f9f8ee','#d7e5d5');
 const g=c.createRadialGradient(1060,240,38,950,360,525);g.addColorStop(0,'#fffdf5');g.addColorStop(1,'#f0f6ea00');rect(0,0,W,H,g);
 smallBrand(76,83,ink);
 txt('450 000 ₸',67,370,100,610,ink,'left',-4);
 txt('Новый получатель',77,426,32,480,'#40584b','left',-.8);
 txt('Демонстрационный перевод',78,645,17,500,'#53685b');
 c.save();c.translate(0,8*(1-ease(u/.7)));device(799,34,346+7*ease(u/5.2),u);c.restore();
}
const X=sec=>186+sec*219;
function bracket(x1,x2,y,col,down=false){
 const a=down?-1:1;
 path([[x1,y+a*7],[x1,y],[x2,y],[x2,y+a*7]],col,1.5);
}
function field(t){
 bg('#0b2019','#182e24');
 const last=t-8.7, showMotion=ease((t-14.65)/.9), windows=ease((t-20.65)/.75);
 txt('Ритм перевода',70,129,56,590,paper,'left',-2.4);
 const lane=lerp(358,291,showMotion), track=470;
 const first=t-10.5, horizon=4.5;
 const reveal=ease((last+.05)/.8);
 faded(reveal,()=>{
  for(let sec=0;sec<=4;sec++){
   const x=X(sec);path([[x,220],[x,546]],'#a2c7ae26',.8);
   txt(String(sec)+' с',x,575,17,520,soft,'center');
  }
  path([[X(0),lane],[X(horizon),lane]],'#618372',1.5);
  txt('Касания',71,lane+5,19,580,paper);
 });
 D.keys.forEach((sec,i)=>{
   let age=first-sec;
   if(age<0)return;
   const x=X(sec),f=ease(age/.16);
   rect(x-4,lane-21*f,8,42*f,green,4);dot(x,lane-21*f,4.1,green);
   if(age<.41){c.save();c.strokeStyle='rgba(186,244,204,'+(1-age/.41)*.64+')';c.lineWidth=1.5;c.beginPath();c.arc(x,lane,8+34*(age/.41),0,Math.PI*2);c.stroke();c.restore();}
 });
 [[.8,1.9],[2.2,3.3]].forEach(([a,b])=>faded(ease((first-b)/.28)*(1-windows),()=>{
   bracket(X(a)+5,X(b)-5,lane-53,amber);txt('1,1 с',X((a+b)/2),lane-68,20,570,amber,'center');
 }));
 faded(showMotion,()=>{
   txt('Движение',71,track+5,19,580,paper);
   path([[X(0),track],[X(horizon),track]],'#557766',1);
   const n=Math.max(2,Math.floor(D.motion.length*ease((t-14.75)/2)));
   path(D.motion.slice(0,n).map(([sec,az])=>[X(sec),track-az/peakAz*65]),'#abd2bc',1.75);
 });
 if(windows>0){
  const slide=ease((t-22.8)/.65)+ease((t-24.35)/.65);
  const x=X(slide),right=X(slide+2);
  faded(windows,()=>{rect(x,205,right-x,318,'#98e2b115');path([[x,523],[x,205],[right,205],[right,523]],green,2);txt('Окно 2 с',(x+right)/2,189,23,640,green,'center');});
 }
}
function architecture(t){
 const u=t-26.5;bg('#0b2019','#182e24');
 txt('Профиль сеанса',70,128,56,590,paper,'left',-2.3);
 const y=392, c1=220,c2=617,c3=1038;
 path([[320,y],[505,y]],'#719180',1.4);path([[728,y],[911,y]],'#719180',1.4);
 // The statistical branch joins the learned temporal representation before the embedding.
 faded(ease((u-3.9)/1.1),()=>{
  path([[315,336],[370,269],[847,269],[906,335]],'#668575',1.1);
  txt('Признаки сеанса',608,251,18,530,soft,'center');
 });
 const scan=(u%2.3)/2.3;
 for(let k=0;k<3;k++){
  const yy=340+k*50;path([[113,yy],[312,yy]],'#526b5d',.8);
  if(k===0){D.keys.forEach(sec=>rect(113+sec*44,yy-10,3.5,20,green,1.7));}
  else if(k===1){path(D.motion.map(([sec,a])=>[113+sec*44,yy-a/peakAz*21]),green,1.7);}
  else {D.windows.forEach((v,i)=>{const h=5+48*(v.key_interval||0);rect(115+i*38,yy-h/2,23,h,soft,2);});}
 }
 rect(111+scan*138,314,49,153,'#b7f7cd15');
 path([[111+scan*138,465],[111+scan*138,314],[160+scan*138,314]],green,1);
 txt('Сигналы',c1,544,29,570,paper,'center');
 const ampMax=Math.max(...D.activation.flat().map(Math.abs))||1;
 for(let k=0;k<7;k++){const arr=D.activation[k],yy=318+k*22;
  path(arr.map((val,i)=>[521+i/(arr.length-1)*192,yy-val/ampMax*18]),k%2?'#669f81':'#b6edc8',1.8);}
 txt('1D-CNN',c2,544,31,640,paper,'center');
 const appear=prm(u,.8,4.1), vmax=Math.max(...D.vector.map(Math.abs));
 D.vector.forEach((v,i)=>{const x=930+(i%16)*13.2,yy=336+Math.floor(i/16)*14.3,a=clamp((appear*152-i)/14);
  if(a<=0)return;
  const intensity=.2+.8*Math.sqrt(Math.abs(v)/vmax);
  faded(a,()=>rect(x,yy,9.9,10.4,v<0?'rgba(205,173,123,'+intensity+')':'rgba(145,229,175,'+intensity+')',1.8));});
 faded(ease((u-1.3)/.6),()=>txt('128 чисел',c3,544,30,610,paper,'center'));
 for(const [start,x1,x2] of [[0,325,502],[.9,735,910]]){if(u>start){const q=((u-start)%2.05)/2.05;dot(lerp(x1,x2,q),y,4,green);}}
}
function policy(t){
 const u=t-35.2;bg('#eeeeda','#f8f6eb');
 txt('Решение по переводу',70,128,54,590,ink,'left',-2.1);
 const col='#406a50';
 const at=145;
 for(const [gi,start] of [[0,at],[1,at+91],[2,at+182]])for(let j=0;j<3;j++)rect(start+j*11,238,5,31,col,2.5);
 bracket(at+26,at+89,223,'#9a722f');bracket(at+117,at+180,223,'#9a722f');
 txt('Две паузы по 1,1 с',141,328,32,560,ink,'left',-.9);
 faded(ease((u-.65)/.6),()=>{c.strokeStyle=col;c.lineWidth=2.4;c.beginPath();c.arc(158,414,11,0,2*Math.PI);c.stroke();path([[137,446],[141,435],[150,431],[166,431],[175,437],[179,446]],col,2.2);
  txt('Новый получатель',140,496,32,560,ink,'left',-.9);});
 faded(ease((u-1.55)/.8),()=>{path([[477,281],[524,281],[574,365],[630,365]],'#829c87',1.5);path([[477,452],[524,452],[574,365]],'#829c87',1.5);dot(574,365,4,col);});
 faded(ease((u-2.15)/.7),()=>{shield(704,223,1.5,col);txt('Перевод',697,357,64,650,ink,'left',-2.8);txt('приостановлен',697,432,57,580,ink,'left',-2.5);});
}
function outcome(t){
 const u=t-41.65;bg('#ebf0e5','#e0e9db');
 txt('После перевода',69,120,53,590,ink,'left',-2);
 const top=218;
 for(const [im,x,label] of [[A.receipt,132,'Клиент'],[A.guardian,700,'Доверенный контакт']]){
  const w=449,h=427;
  txt(label,x,top-26,27,600,ink,'left',-.6);
  c.save();c.shadowColor='#23372922';c.shadowBlur=18;c.shadowOffsetY=7;rect(x,top,w,h,'#fff',12);c.restore();
  c.save();c.beginPath();c.roundRect(x,top,w,h,12);c.clip();
  if(im===A.receipt){
    const scale=(w-24)/im.width;
    const cropH=im.height*.79;
    c.drawImage(im,0,0,im.width,cropH,x+12,top+7,w-24,cropH*scale);
  }else{
    const ih=h-14,iw=ih*im.width/im.height;
    c.drawImage(im,x+(w-iw)/2,top+7,iw,ih);
  }
  c.restore();
 }
}
function end(t){
 bg('#0b1b14','#193323');
 const u=t-47.8, p=ease(u/.85);
 shield(339,309,2.65,'#a8e8bc',p);
 faded(ease((u-.10)/.65),()=>txt('SANA Shield',464,386,76,670,paper,'left',-3.6));
}
const scenes=[[0,intro],[3,transfer],[8.7,field],[26.5,architecture],[35.2,policy],[41.65,outcome],[47.8,end]];
window.ready=(async()=>{
 await Promise.all(['hero','transfer','keypad','receipt','guardian'].map(async name=>{const im=new Image();im.src='../assets/'+name+'.png';await im.decode();A[name]=im;}));
 await Promise.all([document.fonts.load('580 36px Manrope','Пример'),document.fonts.load('580 36px Manrope','Shield')]);
 D=await (await fetch('../assets/data.json')).json();peakAz=Math.max(.00001,...D.motion.map(([,az])=>Math.abs(az)));
})();
window.paint=(t,outWidth=1920)=>{
 if(cv.width!==outWidth){cv.width=outWidth;cv.height=outWidth*9/16;}
 c.setTransform(cv.width/W,0,0,cv.height/H,0,0);
 const index=scenes.findLastIndex(([s])=>t>=s);scenes[index][1](t);
};
