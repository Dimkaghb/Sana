from pathlib import Path
import json
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter,sosfilt
root=Path(__file__).resolve().parents[1]
assets=root/'assets'; sr=48000; end=51
rng=np.random.default_rng(41)
music=np.zeros((end*sr,2),np.float32); vo=music.copy(); fx=music.copy()
def add(dst,start,sig,pan=0):
 i=round(start*sr)
 if i>=len(dst):return
 signal=sig[:len(dst)-i]
 dst[i:i+len(signal),0]+=signal*np.sqrt((1-pan)/2)
 dst[i:i+len(signal),1]+=signal*np.sqrt((1+pan)/2)
def tm(d):return np.arange(int(sr*d))/sr
def freq(n):return 440*2**((n-69)/12)
def env(t,a,r):return (1-np.exp(-t/a))*np.exp(-t/r)
def bell(start,n,gain,pan=0):
 t=tm(2.7); f=freq(n); ph=2*np.pi*f*t
 sig=gain*env(t,.007,.58)*(np.sin(ph+.88*np.exp(-t/.20)*np.sin(2*ph))+.17*np.sin(2.004*ph)*np.exp(-t/.8))
 add(music,start,sig,pan)
 for lag,amt in [(.19,.14),(.38,.085),(.79,.045)]:add(music,start+lag,sig*amt,-pan)
def chord(start,notes,length):
 t=tm(length+1.65); amp=np.minimum(1,t/.63)*(1-np.exp(-t/.24))*np.exp(-np.maximum(0,t-length)/.58)
 for j,n in enumerate(notes):
  ph=2*np.pi*freq(n)*t; sig=.052*amp*(np.sin(ph+.10*np.sin(.9*t))+.23*np.sin(2*ph)*np.exp(-t/4)+.12*np.sin(ph*1.002))
  add(music,start,sig,[-.62,.15,.6,-.27,.29][j])
def kick(start,vol):
 t=tm(.32); add(music,start,vol*np.sin(2*np.pi*(48*t+1.8*(1-np.exp(-t/.031))))*env(t,.006,.086))
def tap(start,strength):
 t=tm(.11); osc=np.sin(2*np.pi*840*t)+.4*np.sin(2*np.pi*1480*t)
 sig=strength*env(t,.0012,.011)*(osc+.23*rng.standard_normal(len(t)))
 add(fx,start,sig,.12)
beat=.625; bar=2.5
chords=[[50,57,60,64,69],[46,53,57,60,65],[53,60,64,67,69],[48,55,60,62,67]]
for idx,s in enumerate(np.arange(0,50,bar)):
 notes=chords[(idx//2)%4]
 if idx%2==0:chord(s,notes,bar*2-.18)
 if 8<s<15:continue
 for j,pos in enumerate([0,.75,1.5,2.75,3.5]):
  if (idx+j)%6==0:continue
  bell(s+pos*beat,notes[[1,3,2,4,3][j]]+(12 if j in (1,4) else 0),.068 if idx>1 else .047,[-.32,.44,-.2,.58,.15][j])
 if 4<s<46:
  kick(s,.14);kick(s+2*beat,.09)
  t=tm(.105); noise=sosfilt(butter(2,6500,fs=sr,btype='highpass',output='sos'),rng.standard_normal(len(t)))
  for xx in [.5,1.5,2.5,3.5]:add(music,s+xx*beat,.014*noise*env(t,.003,.023),(-1)**idx*.38)
 if idx%2==0:
  t=tm(3.1);ph=2*np.pi*freq(notes[0]-12)*t;add(music,s,.12*env(t,.024,.79)*(np.sin(ph)+.15*np.sin(2*ph)))
texts=json.loads((assets/'voice.json').read_text()); starts=[.52,3.42,9.12,14.93,20.88,26.87,35.48,41.99,48.76]
def timestamp(s):
 ms=round(s*1000);return f'{ms//3600000:02}:{ms//60000%60:02}:{ms//1000%60:02},{ms%1000:03}'
sub=[];clock=tm(end);duck=np.ones(len(clock))
for j,(part,start) in enumerate(zip(texts,starts),1):
 _,raw=wavfile.read(assets/('voice-'+part['id']+'.wav'))
 raw=sosfilt(butter(2,68,btype='highpass',fs=sr,output='sos'),raw)
 voiced=raw[np.abs(raw)>.009]; raw=raw*(.151/max(.03,np.sqrt(np.mean(voiced**2))))
 add(vo,start,raw,0)
 finish=start+len(raw)/sr
 edge=np.minimum(np.clip((clock-start+.22)/.22,0,1),np.clip((finish+.36-clock)/.36,0,1))
 duck=np.minimum(duck,1-.53*edge)
 sub.append(f"{j}\n{timestamp(start)} --> {timestamp(finish)}\n{part['text']}\n")
for k in json.loads((assets/'data.json').read_text())['keys']:tap(10.5+k,.25)
t=tm(1.2)
for start,hz in [(35.38,322),(47.88,482)]:
 add(fx,start,.11*env(t,.005,.29)*(np.sin(2*np.pi*hz*t)+.20*np.sin(2*np.pi*hz*1.5*t)))
music*=duck[:,None]
music*=np.minimum(np.clip(clock/.4,0,1),np.clip((end-.14-clock)/1.45,0,1))[:,None]
master=vo+music+fx
wavfile.write(root/'work/mix-premaster.wav',sr,master.astype(np.float32))
(root/'SANA-Shield-RU.srt').write_text('\n'.join(sub))
print('Premaster peak',np.abs(master).max())
