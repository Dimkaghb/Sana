from pathlib import Path
import json
import torch
import numpy as np
from scipy.io import wavfile

base = Path(__file__).resolve().parents[1]
lines = [
 ("hook", "Почему банк задержал этот перевод?"),
 ("transfer", "Четыреста пятьдесят тысяч тенге. Получатель новый. Пока всё выглядит обычно."),
 ("rhythm", "Прислушайтесь к ритму. Три нажатия, пауза. И снова три."),
 ("privacy", "Телефон передаёт время касаний и данные о движении. Сами цифры в эту запись не попадают."),
 ("windows", "Запись делится на отрезки по две секунды. Каждый следующий начинается на секунду позже."),
 ("encoder", "Свёрточная сеть улавливает короткие движения. Вместе с другими признаками они превращаются в сто двадцать восемь чисел — профиль сеанса."),
 ("decision", "В нашем примере паузы повторяются, а получатель новый. По этим признакам банк приостанавливает перевод."),
 ("guardian", "Клиент видит обычную квитанцию. Близкий человек получает просьбу перезвонить."),
 ("brand", "Сана Шилд.")
]
torch.set_num_threads(4)
model = torch.package.PackageImporter(str(base/'work/voice-model.pt')).load_pickle('tts_models','model')
records=[]
for name,line in lines:
    with torch.inference_mode():
        audio=model.apply_tts(text=line, speaker='xenia', sample_rate=48000, put_accent=True, put_yo=True).numpy()
    idx=np.flatnonzero(np.abs(audio)>.003)
    audio=audio[max(0,idx[0]-1800):min(len(audio),idx[-1]+4800)]
    wavfile.write(base/'assets'/f'voice-{name}.wav', 48000, audio.astype(np.float32))
    records.append(dict(id=name,text=line,seconds=round(len(audio)/48000,3)))
(base/'assets/voice.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
print([(r['id'],r['seconds']) for r in records],flush=True)
