const {chromium}=require(process.cwd()+'/frontend/node_modules/playwright');
const {createServer}=require('node:http');
const {readFile,writeFile,stat}=require('node:fs/promises');
const {spawn}=require('node:child_process');
const {once}=require('node:events');
const path=require('node:path');
const base=path.resolve(__dirname,'..');
const fps=30,length=51;
(async()=>{
 const serve=createServer(async(req,res)=>{
  try{
   const url=new URL(req.url,'http://localhost');
   const f=path.resolve(base,'.'+url.pathname);
   if(!f.startsWith(base+'/'))throw Error('path');
   const data=await readFile(f);res.setHeader('Content-Type',({'.js':'text/javascript','.html':'text/html','.woff2':'font/woff2','.png':'image/png','.json':'application/json'})[path.extname(f)]||'application/octet-stream');res.end(data);
  }catch{res.writeHead(404);res.end();}
 });
 serve.listen(0,'127.0.0.1');await once(serve,'listening');
 const browser=await chromium.launch({channel:'chrome',args:['--disable-background-timer-throttling','--disable-renderer-backgrounding']});
 try{
  const p=await browser.newPage();p.on('pageerror',e=>console.error(e.message));
  await p.goto('http://127.0.0.1:'+serve.address().port+'/src/film.html');await p.evaluate(()=>window.ready);
  const frame=async(t,w)=>Buffer.from(await p.evaluate(([t,w])=>{window.paint(t,w);return document.querySelector('canvas').toDataURL('image/jpeg',.96).split(',')[1];},[t,w]),'base64');
  if(process.argv.includes('--preview')){
   for(const t of [1.7,5.5,13.9,18.5,24.8,31.7,39.2,45.1,49.8])await writeFile(path.join(base,'work','frame-'+String(Math.round(t*10)).padStart(3,'0')+'.jpg'),await frame(t,960));
  }else{
   const cmd=spawn('ffmpeg',['-hide_banner','-loglevel','error','-y','-f','image2pipe','-framerate',String(fps),'-c:v','mjpeg','-i','pipe:0','-an','-c:v','libx264','-crf','16','-preset','veryfast','-pix_fmt','yuv420p','-colorspace','bt709','-color_primaries','bt709','-color_trc','bt709','-vf','scale=out_color_matrix=bt709:out_range=tv','-movflags','+faststart',path.join(base,'work/picture.mp4')],{stdio:['pipe','inherit','inherit']});
   const finished=once(cmd,'close');let last=-1;
   for(let i=0;i<length*fps;i++){
    if(!cmd.stdin.write(await frame(i/fps,1920)))await once(cmd.stdin,'drain');
    const part=Math.floor(i/(fps*10));if(part!==last){last=part;console.log('Rendered through',Math.round(i/fps),'seconds');}
   }
   cmd.stdin.end();const [code]=await finished;if(code)throw Error('encode '+code);
  }
 }finally{await browser.close();serve.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
