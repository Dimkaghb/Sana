const {chromium}=require(process.cwd()+'/frontend/node_modules/playwright');
const path=require('node:path');
const dir=path.resolve(__dirname,'../assets');
(async()=>{
 const browser=await chromium.launch({channel:'chrome'});
 try {
 const page=await browser.newPage({viewport:{width:390,height:844},deviceScaleFactor:2,locale:'ru-RU'});
 await page.goto('http://127.0.0.1:8000/mobile?mode=fixtures');
 const pick=page.locator('.scenario-picker select');
 await pick.selectOption('dictation');
 await page.getByRole('button',{name:/Включить защиту/}).click();
 const key=(key)=>page.locator('.keypad').getByRole('button',{name:key,exact:true}).click();
 for(const k of '42424242') await key(k);
 await page.locator('.amount-field').nth(1).click();
 for(let i=0;i<5;i++) await key('Удалить');
 for(const k of '450000') await key(k);
 await page.evaluate(()=>document.fonts.ready);
 await page.locator('.transfer').screenshot({path:dir+'/transfer.png'});
 await page.locator('.keypad').screenshot({path:dir+'/keypad.png'});
 await page.getByText('Потяните для перевода').locator('..').press('Enter');
 await page.locator('.receipt').screenshot({path:dir+'/receipt.png'});
 await page.goto('http://127.0.0.1:8000/guardian?mode=fixtures');
 await page.evaluate(()=>{document.documentElement.dataset.theme='light'});
 await page.locator('.guardian article').first().screenshot({path:dir+'/guardian.png'});
 console.log('Captured transfer, keypad, receipt and Guardian from the fixture workspace.');
 }finally{await browser.close()}
})().catch(e=>{console.error(e.message);process.exitCode=1});
