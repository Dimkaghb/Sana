from pathlib import Path
import sys,json,torch
base=Path(__file__).resolve().parents[1]
repo=base.parents[1]
sys.path.insert(0,str(repo))
from ml.encoder import Encoder,tensors
from ml.features import extract
from contracts.windows import sliding_windows
p=json.loads((repo/'contracts/fixtures/dictation/telemetry.json').read_text())
modelpath=repo/'ml/artifacts/synthetic-v2'
manifest=json.loads((modelpath/'manifest.json').read_text())
model=Encoder(attention=manifest['attention']).eval()
model.load_state_dict(torch.load(modelpath/'encoder.pt',map_location='cpu',weights_only=True))
f=extract(p)
with torch.inference_mode():
    _,seq,_=tensors([f])
    norm=((seq-model.seq_center)/model.seq_scale).nan_to_num().clamp(-5,5)
    activation=model.temporal(norm.transpose(1,2))[0,:7].tolist()
    vector=model.embed([f])[0].tolist()
data={'keys':[k['down_ms']/1000 for k in p['keystrokes']],'motion':[[v['t_ms']/1000,v['az']] for v in p['imu_samples']],'duration':p['duration_ms']/1000,'windows':sliding_windows(p),'activation':activation,'vector':vector}
(base/'assets/data.json').write_text(json.dumps(data))
print(len(vector),len(data['windows']),data['keys'])
